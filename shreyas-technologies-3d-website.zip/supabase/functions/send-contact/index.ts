// Supabase Edge Function (Deno): send-contact
// Receives the website enquiry form and delivers it by email through Resend.
//
// Secrets (set with `supabase secrets set`, NEVER in frontend code):
//   RESEND_API_KEY      (required) API key from https://resend.com
//   CONTACT_TO_EMAIL    (optional) default: shreyascoding2313@gmail.com
//   CONTACT_FROM_EMAIL  (optional) default: "SHREYAS TECHNOLOGIES <onboarding@resend.dev>"
//                       Use an address on a domain you verified in Resend for production.
//   ALLOWED_ORIGINS     (optional) comma separated list, e.g. https://yourdomain.com
//   RATE_LIMIT_SALT     (optional) extra salt for hashing visitor IPs
// Provided automatically by Supabase: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const TO_EMAIL = Deno.env.get("CONTACT_TO_EMAIL") ?? "shreyascoding2313@gmail.com";
const FROM_EMAIL = Deno.env.get("CONTACT_FROM_EMAIL") ?? "SHREYAS TECHNOLOGIES <onboarding@resend.dev>";
const ALLOWED = (Deno.env.get("ALLOWED_ORIGINS") ?? "").split(",").map((s) => s.trim()).filter(Boolean);

const MAX_PER_IP_HOUR = 3;
const MAX_PER_IP_DAY = 8;
const MAX_PER_EMAIL_DAY = 4;
const MIN_FILL_MS = 3000; // humans take longer than 3s to fill the form

const SERVICES = [
  "Website Development", "Full-stack Development", "Software Engineering", "AI & LLM Solutions",
  "Mobile Applications", "Cloud Architecture", "Cybersecurity", "UI/UX Design",
  "3D Interactive Websites", "Automation", "Something else",
];
const BUDGETS = ["Under $1,000", "$1,000 – $5,000", "$5,000 – $15,000", "$15,000+", "Not sure yet"];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function corsHeaders(origin: string | null): Record<string, string> {
  const allow = ALLOWED.length === 0 ? "*" : origin && ALLOWED.includes(origin) ? origin : ALLOWED[0];
  return {
    "Access-Control-Allow-Origin": allow,
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}

function json(body: unknown, status: number, origin: string | null, extra: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(origin), "Content-Type": "application/json", ...extra },
  });
}

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
const oneLine = (s: string) => s.replace(/[\r\n\t]+/g, " ").trim();

async function sha256(text: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  const origin = req.headers.get("origin");

  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders(origin) });
  if (req.method !== "POST") return json({ ok: false, message: "Method not allowed" }, 405, origin);

  if (ALLOWED.length > 0 && (!origin || !ALLOWED.includes(origin))) {
    return json({ ok: false, message: "Origin not allowed" }, 403, origin);
  }

  // ---- configuration check: never pretend ----
  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
  const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!RESEND_API_KEY || !SUPABASE_URL || !SERVICE_KEY) {
    return json(
      { ok: false, error: "not_configured", message: "Email delivery is not configured on the server." },
      503,
      origin,
    );
  }

  // ---- parse ----
  let raw: Record<string, unknown>;
  try {
    const text = await req.text();
    if (text.length > 20000) return json({ ok: false, message: "Payload too large" }, 413, origin);
    raw = JSON.parse(text);
  } catch {
    return json({ ok: false, message: "Invalid JSON" }, 400, origin);
  }
  const str = (k: string) => (typeof raw[k] === "string" ? (raw[k] as string) : "");

  // ---- spam protection: honeypot + minimum fill time ----
  if (str("website").length > 0) {
    // Pretend nothing happened to bots, but do not send and do not claim an email id.
    return json({ ok: false, message: "Rejected" }, 400, origin);
  }
  const elapsed = Number(raw["elapsedMs"]);
  if (!Number.isFinite(elapsed) || elapsed < MIN_FILL_MS) {
    return json({ ok: false, message: "Please take a moment to complete the form." }, 400, origin);
  }

  // ---- validation ----
  const name = oneLine(str("name"));
  const email = oneLine(str("email"));
  const phone = oneLine(str("phone"));
  const service = oneLine(str("service"));
  const budget = oneLine(str("budget"));
  const message = str("message").trim();

  const errors: Record<string, string> = {};
  if (name.length < 2 || name.length > 100) errors.name = "Please enter your full name.";
  if (!EMAIL_RE.test(email) || email.length > 254) errors.email = "Please enter a valid email address.";
  if (phone && !/^[+()\d\s.-]{7,20}$/.test(phone)) errors.phone = "Invalid phone number.";
  if (!SERVICES.includes(service)) errors.service = "Choose a service.";
  if (!BUDGETS.includes(budget)) errors.budget = "Choose a budget range.";
  if (message.length < 20 || message.length > 4000) errors.message = "Description must be 20–4000 characters.";
  if (Object.keys(errors).length) return json({ ok: false, errors }, 400, origin);

  // ---- rate limiting (fails closed) ----
  const supabase = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });
  const ip = (req.headers.get("x-forwarded-for") ?? req.headers.get("cf-connecting-ip") ?? "unknown")
    .split(",")[0].trim();
  const salt = Deno.env.get("RATE_LIMIT_SALT") ?? SERVICE_KEY.slice(0, 16);
  const ipHash = await sha256(`${salt}:ip:${ip}`);
  const emailHash = await sha256(`${salt}:email:${email.toLowerCase()}`);

  const since = (ms: number) => new Date(Date.now() - ms).toISOString();
  const count = async (col: "ip_hash" | "email_hash", val: string, ms: number) => {
    const { count: c, error } = await supabase
      .from("contact_attempts")
      .select("id", { count: "exact", head: true })
      .eq(col, val)
      .gte("created_at", since(ms));
    if (error) throw error;
    return c ?? 0;
  };

  try {
    const [h, d, e] = await Promise.all([
      count("ip_hash", ipHash, 3600_000),
      count("ip_hash", ipHash, 86_400_000),
      count("email_hash", emailHash, 86_400_000),
    ]);
    if (h >= MAX_PER_IP_HOUR || d >= MAX_PER_IP_DAY || e >= MAX_PER_EMAIL_DAY) {
      return json(
        { ok: false, message: "Too many enquiries. Please try again later." },
        429,
        origin,
        { "Retry-After": "3600" },
      );
    }
    const { error } = await supabase.from("contact_attempts").insert({ ip_hash: ipHash, email_hash: emailHash });
    if (error) throw error;
  } catch (err) {
    console.error("rate limiter error", err);
    return json({ ok: false, message: "Service temporarily unavailable. Please try again shortly." }, 503, origin);
  }

  // ---- send through Resend ----
  const rows: [string, string][] = [
    ["Name", name], ["Email", email], ["Phone", phone || "—"], ["Service", service], ["Budget", budget],
  ];
  const html = `
  <div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0b1020">
    <h2 style="margin:0 0 4px">New project enquiry</h2>
    <p style="margin:0 0 20px;color:#5b6477">SHREYAS TECHNOLOGIES website</p>
    <table style="width:100%;border-collapse:collapse">
      ${rows.map(([k, v]) => `<tr><td style="padding:8px 0;color:#5b6477;width:110px">${k}</td><td style="padding:8px 0"><strong>${esc(v)}</strong></td></tr>`).join("")}
    </table>
    <h3 style="margin:24px 0 8px">Project description</h3>
    <div style="white-space:pre-wrap;line-height:1.6;background:#f3f6fd;padding:16px;border-radius:8px">${esc(message)}</div>
    <p style="margin-top:24px;color:#5b6477;font-size:12px">Reply to this email to respond directly to ${esc(name)}.</p>
  </div>`;
  const text = `${rows.map(([k, v]) => `${k}: ${v}`).join("\n")}\n\n${message}`;

  let res: Response;
  try {
    res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: [TO_EMAIL],
        reply_to: email,
        subject: `New enquiry: ${service} — ${name}`.slice(0, 200),
        html,
        text,
      }),
    });
  } catch (err) {
    console.error("resend network error", err);
    return json({ ok: false, message: "Could not reach the email provider." }, 502, origin);
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data?.id) {
    console.error("resend error", res.status, JSON.stringify(data));
    return json({ ok: false, message: "The email provider rejected the message." }, 502, origin);
  }

  // Success is reported ONLY when Resend confirmed acceptance with a message id.
  return json({ ok: true, id: data.id }, 200, origin);
});
