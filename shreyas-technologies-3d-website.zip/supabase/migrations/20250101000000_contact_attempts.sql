-- Rate-limit log for the send-contact Edge Function.
-- Only hashed identifiers are stored (no raw IPs / emails).
create table if not exists public.contact_attempts (
  id uuid primary key default gen_random_uuid(),
  ip_hash text not null,
  email_hash text not null,
  created_at timestamptz not null default now()
);

create index if not exists contact_attempts_ip_idx on public.contact_attempts (ip_hash, created_at desc);
create index if not exists contact_attempts_email_idx on public.contact_attempts (email_hash, created_at desc);

-- Lock the table down: no policies means anon/authenticated users cannot read or write it.
-- The Edge Function uses the service role key, which bypasses RLS.
alter table public.contact_attempts enable row level security;

-- Optional housekeeping (run via pg_cron or manually):
-- delete from public.contact_attempts where created_at < now() - interval '3 days';
