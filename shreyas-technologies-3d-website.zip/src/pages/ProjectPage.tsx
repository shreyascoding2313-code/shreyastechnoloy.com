import { useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { PROJECTS } from "../data/projects";
import ProjectArt from "../components/ProjectArt";
import { TechLogo } from "../components/TechLogo";
import { useScroll } from "../lib/scroll";

export default function ProjectPage() {
  const { slug } = useParams();
  const { goTo } = useScroll();
  const idx = PROJECTS.findIndex((p) => p.slug === slug);
  const p = PROJECTS[idx];

  useEffect(() => {
    if (p) document.title = `${p.title} — ${p.kind} (Demo) | SHREYAS TECHNOLOGIES`;
    return () => {
      document.title = "SHREYAS TECHNOLOGIES — Enter the Future | 3D Websites, AI & Software Engineering";
    };
  }, [p]);

  if (!p) {
    return (
      <main className="flex min-h-screen flex-col items-center justify-center bg-black px-6 text-center">
        <p className="mono text-cyan-300">404</p>
        <h1 className="mt-4 text-4xl font-light">This project doesn't exist.</h1>
        <Link to="/" className="btn btn-primary mt-8">Back to home</Link>
      </main>
    );
  }
  const next = PROJECTS[(idx + 1) % PROJECTS.length];

  return (
    <main className="bg-black">
      <section className="relative h-[78svh] min-h-[520px] overflow-hidden">
        <div className="absolute inset-0 scale-110">
          <ProjectArt project={p} live />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/55 to-black/30" />
        <div className="relative mx-auto flex h-full max-w-[1500px] flex-col justify-end px-5 pb-14 sm:px-10">
          <Link to="/" className="mono mb-8 text-slate-300 hover:text-white" onClick={() => setTimeout(() => goTo("projects"), 50)}>
            ← ALL PROJECTS
          </Link>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mono mb-3" style={{ color: p.accent }}>
            {p.category} · {p.kind}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 40, filter: "blur(10px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ duration: 1 }}
            className="chrome-text text-[clamp(3.5rem,14vw,11rem)] font-semibold leading-[0.9] tracking-tight"
          >
            {p.title}
          </motion.h1>
          <p className="mt-6 max-w-2xl text-xl font-light text-slate-100/90">{p.tagline}</p>
        </div>
      </section>

      <section className="mx-auto grid max-w-[1500px] gap-16 px-5 py-20 sm:px-10 lg:grid-cols-[1.2fr_0.8fr]">
        <div>
          <p className="mono mb-3 inline-block rounded-full border border-amber-300/40 bg-amber-300/10 px-4 py-2 text-amber-200">
            DEMO CONCEPT · NOT A CLIENT PROJECT
          </p>
          <h2 className="mt-6 text-3xl font-light">Overview</h2>
          <p className="mt-4 max-w-2xl text-lg leading-relaxed text-slate-300/85">{p.overview}</p>

          <h2 className="mt-14 text-3xl font-light">Design goals</h2>
          <ul className="mt-6 divide-y divide-white/10 border-y border-white/10">
            {p.goals.map((g, i) => (
              <li key={g} className="flex gap-6 py-5">
                <span className="mono text-cyan-300">0{i + 1}</span>
                <span className="text-lg text-slate-200">{g}</span>
              </li>
            ))}
          </ul>
        </div>

        <aside className="space-y-10">
          <div className="glass rounded-3xl p-7">
            <p className="mono mb-5 text-sky-300">KEY FEATURES</p>
            <ul className="space-y-3">
              {p.features.map((f) => (
                <li key={f} className="flex items-center gap-3 text-slate-200">
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-300 shadow-[0_0_10px_#38e1ff]" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
          <div className="glass rounded-3xl p-7">
            <p className="mono mb-5 text-sky-300">TECHNOLOGY</p>
            <ul className="grid grid-cols-2 gap-4">
              {p.stack.map((t) => (
                <li key={t.name} className="flex items-center gap-3">
                  <TechLogo icon={t.icon} size={26} />
                  <span className="text-sm text-slate-200">{t.name}</span>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </section>

      <section className="border-t border-white/10 px-5 py-20 sm:px-10">
        <div className="mx-auto flex max-w-[1500px] flex-col items-start justify-between gap-10 md:flex-row md:items-end">
          <div>
            <p className="mono text-slate-500">NEXT PROJECT</p>
            <Link to={`/project/${next.slug}`} className="chrome-text mt-3 block text-[clamp(2.5rem,8vw,6rem)] font-semibold leading-none transition hover:opacity-80">
              {next.title} →
            </Link>
          </div>
          <button className="btn btn-primary" onClick={() => goTo("contact")}>
            Start a project like this
          </button>
        </div>
      </section>
    </main>
  );
}
