import Hero from "../components/Hero";
import About from "../components/About";
import Services from "../components/Services";
import Technologies from "../components/Technologies";
import AILab from "../components/AILab";
import Projects from "../components/Projects";
import Contact from "../components/Contact";

export default function Home({ ready }: { ready: boolean }) {
  return (
    <main>
      <Hero ready={ready} />
      <About />
      <Services />
      <Technologies />
      <AILab />
      <Projects />
      <Contact />
    </main>
  );
}
