import { useCallback, useState } from "react";
import { HashRouter, Route, Routes } from "react-router-dom";
import { ScrollProvider } from "./lib/scroll";
import { INTRO_KEY, prefersReducedMotion } from "./lib/store";
import Intro from "./components/Intro";
import Nav from "./components/Nav";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import ProjectPage from "./pages/ProjectPage";

function shouldShowIntro(): boolean {
  if (prefersReducedMotion()) return false;
  try {
    return localStorage.getItem(INTRO_KEY) !== "1";
  } catch {
    return true;
  }
}

export default function App() {
  const [showIntro, setShowIntro] = useState(shouldShowIntro);
  const [ready, setReady] = useState(!shouldShowIntro());

  const onReveal = useCallback(() => setReady(true), []);
  const onDone = useCallback(() => setShowIntro(false), []);

  const replay = () => {
    try {
      localStorage.removeItem(INTRO_KEY);
    } catch {
      /* ignore */
    }
    window.scrollTo({ top: 0 });
    setReady(false);
    setShowIntro(true);
  };

  return (
    <HashRouter>
      <ScrollProvider>
        <a
          href="#main-content"
          onClick={(e) => {
            e.preventDefault();
            document.getElementById("about")?.scrollIntoView();
          }}
          className="fixed left-4 top-4 z-[200] -translate-y-20 rounded bg-white px-4 py-2 text-black focus:translate-y-0"
        >
          Skip to content
        </a>
        <Nav />
        <Routes>
          <Route path="/" element={<Home ready={ready} />} />
          <Route path="/project/:slug" element={<ProjectPage />} />
          <Route path="*" element={<ProjectPage />} />
        </Routes>
        <Footer onReplay={replay} />
        {showIntro && <Intro onReveal={onReveal} onDone={onDone} />}
      </ScrollProvider>
    </HashRouter>
  );
}
