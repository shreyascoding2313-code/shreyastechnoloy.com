import { createContext, useCallback, useContext, useEffect, useMemo, useRef } from "react";
import type { ReactNode } from "react";
import Lenis from "lenis";
import gsap from "gsap";
import { useLocation, useNavigate } from "react-router-dom";
import { ctl, prefersReducedMotion } from "./store";

interface ScrollApi {
  goTo: (id: string) => void;
  lock: () => void;
  unlock: () => void;
}
const Ctx = createContext<ScrollApi>({ goTo: () => {}, lock: () => {}, unlock: () => {} });
export const useScroll = () => useContext(Ctx);

export function ScrollProvider({ children }: { children: ReactNode }) {
  const lenisRef = useRef<Lenis | null>(null);
  const pending = useRef<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => {
      ctl.scroll = Math.min(1, Math.max(0, window.scrollY / Math.max(1, window.innerHeight)));
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    let tick: ((t: number) => void) | null = null;
    if (!prefersReducedMotion()) {
      const lenis = new Lenis({ lerp: 0.09, smoothWheel: true });
      lenisRef.current = lenis;
      tick = (t: number) => lenis.raf(t * 1000);
      gsap.ticker.add(tick);
      gsap.ticker.lagSmoothing(0);
    }
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (tick) gsap.ticker.remove(tick);
      lenisRef.current?.destroy();
      lenisRef.current = null;
    };
  }, []);

  const scrollToId = useCallback((id: string) => {
    const el = id === "home" ? null : document.getElementById(id);
    const lenis = lenisRef.current;
    if (id === "home" || !el) {
      if (lenis) lenis.scrollTo(0, { duration: 1.6 });
      else window.scrollTo({ top: 0 });
      return;
    }
    if (lenis) lenis.scrollTo(el, { duration: 1.6, offset: 0 });
    else el.scrollIntoView();
  }, []);

  const goTo = useCallback(
    (id: string) => {
      if (location.pathname !== "/") {
        pending.current = id;
        navigate("/");
      } else {
        scrollToId(id);
      }
    },
    [location.pathname, navigate, scrollToId]
  );

  // After route changes: handle pending section jump, otherwise reset to top.
  useEffect(() => {
    lenisRef.current?.resize();
    if (pending.current && location.pathname === "/") {
      const id = pending.current;
      pending.current = null;
      window.setTimeout(() => scrollToId(id), 350);
    } else {
      window.scrollTo({ top: 0 });
      lenisRef.current?.scrollTo(0, { immediate: true });
    }
  }, [location.pathname, scrollToId]);

  const lock = useCallback(() => {
    lenisRef.current?.stop();
    document.body.style.overflow = "hidden";
  }, []);
  const unlock = useCallback(() => {
    lenisRef.current?.start();
    document.body.style.overflow = "";
  }, []);
  const api = useMemo<ScrollApi>(() => ({ goTo, lock, unlock }), [goTo, lock, unlock]);

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}
