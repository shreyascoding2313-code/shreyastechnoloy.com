import { useEffect, useRef, useState } from "react";

/** Shared, non-reactive control state read inside the render loops (no React re-renders). */
export const ctl = {
  scroll: 0, // 0..1 across the hero
  arena: 0, // 0..1 arena-mode transition (GSAP tweened)
  rotX: 0,
  rotY: 0,
  dragging: false,
  orbit: 1, // orbital ring speed multiplier
  preset: 0,
};

export const PRESETS = [
  { name: "ELECTRIC", color: "#2f6bff", atten: "#0a35ff", glow: "#38b6ff" },
  { name: "CYAN", color: "#27e6ff", atten: "#0a8cff", glow: "#7ff3ff" },
  { name: "VIOLET", color: "#7a5cff", atten: "#3a1bff", glow: "#b49cff" },
] as const;

export type Quality = "high" | "low";

export function prefersReducedMotion(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export function detectQuality(): Quality {
  if (typeof window === "undefined") return "low";
  const small = window.matchMedia("(max-width: 820px)").matches;
  const coarse = window.matchMedia("(pointer: coarse)").matches;
  const nav = navigator as Navigator & { deviceMemory?: number };
  const weak = (nav.deviceMemory ?? 8) <= 4 || (navigator.hardwareConcurrency ?? 8) <= 4;
  return small || coarse || weak ? "low" : "high";
}

export function hasWebGL(): boolean {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

/** True while the element intersects the viewport (used to pause heavy render loops). */
export function useInView<T extends Element>(margin = "0px") {
  const ref = useRef<T>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setInView(e.isIntersecting), { rootMargin: margin });
    io.observe(el);
    return () => io.disconnect();
  }, [margin]);
  return [ref, inView] as const;
}

export const INTRO_KEY = "shreyas-intro-seen-v1";

export const AI_MODES = [
  { color: "#38e1ff", speed: 1.0 },
  { color: "#2f7bff", speed: 1.3 },
  { color: "#8b6cff", speed: 0.9 },
  { color: "#38e1ff", speed: 1.6 },
  { color: "#5aa0ff", speed: 1.15 },
  { color: "#a58bff", speed: 1.4 },
] as const;

