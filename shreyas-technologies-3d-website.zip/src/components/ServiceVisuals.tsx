import { useReducedMotion } from "framer-motion";

const C1 = "#38e1ff";
const C2 = "#2f7bff";
const C3 = "#8b6cff";

function Travel({ path, dur = 3, color = "#fff", r = 3.5, begin = "0s" }: { path: string; dur?: number; color?: string; r?: number; begin?: string }) {
  const rm = useReducedMotion();
  if (rm) return null;
  return (
    <circle r={r} fill={color} style={{ filter: `drop-shadow(0 0 6px ${color})` }}>
      <animateMotion dur={`${dur}s`} repeatCount="indefinite" path={path} begin={begin} />
    </circle>
  );
}

const Glow = () => (
  <defs>
    <linearGradient id="sv-g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stopColor={C1} />
      <stop offset="1" stopColor={C3} />
    </linearGradient>
    <radialGradient id="sv-r">
      <stop offset="0" stopColor={C2} stopOpacity=".6" />
      <stop offset="1" stopColor={C2} stopOpacity="0" />
    </radialGradient>
  </defs>
);

const S = { fill: "none", stroke: "url(#sv-g)", strokeWidth: 1.5, strokeLinecap: "round", strokeLinejoin: "round" } as const;

function Web() {
  return (
    <g>
      <rect x="60" y="40" width="280" height="210" rx="14" {...S} />
      <path d="M60 68H340" {...S} />
      {[78, 92, 106].map((x, i) => (
        <circle key={x} cx={x} cy="54" r="3" fill={[C1, C2, C3][i]} />
      ))}
      <rect x="80" y="86" width="150" height="14" rx="4" {...S} />
      <rect x="80" y="110" width="100" height="8" rx="4" {...S} opacity=".6" />
      <rect x="250" y="86" width="70" height="46" rx="8" {...S} />
      {[80, 160, 240].map((x) => (
        <rect key={x} x={x} y="150" width="70" height="80" rx="8" {...S} opacity=".8" />
      ))}
      <Travel path="M80 140 H320 V235 H80 Z" dur={5} color={C1} />
    </g>
  );
}
function Fullstack() {
  const layers = [
    { y: 70, c: C1, l: "UI" },
    { y: 130, c: C2, l: "API" },
    { y: 190, c: C3, l: "DATA" },
  ];
  return (
    <g>
      {layers.map((l) => (
        <g key={l.l}>
          <path d={`M200 ${l.y} L300 ${l.y + 30} L200 ${l.y + 60} L100 ${l.y + 30} Z`} fill={l.c} fillOpacity=".1" stroke={l.c} strokeWidth="1.5" />
          <text x="200" y={l.y + 34} textAnchor="middle" fill="#fff" fontSize="11" letterSpacing="3" fontFamily="monospace">
            {l.l}
          </text>
        </g>
      ))}
      <path d="M200 100V130M200 160V190" stroke="#fff" strokeOpacity=".4" strokeDasharray="3 4" />
      <Travel path="M200 100 V220" dur={2.4} color={C1} />
      <Travel path="M200 220 V100" dur={2.4} color={C3} begin="1.2s" />
    </g>
  );
}
function Software() {
  const lines = [
    [0, 90], [20, 140], [20, 110], [40, 170], [20, 80], [0, 120], [20, 150],
  ];
  return (
    <g>
      <rect x="50" y="40" width="300" height="220" rx="14" {...S} />
      {lines.map(([ind, w], i) => (
        <rect key={i} x={76 + ind} y={66 + i * 26} width={w} height="9" rx="4.5" fill={[C1, C2, C3][i % 3]} opacity=".85">
          <animate attributeName="width" values={`0;${w};${w}`} keyTimes="0;0.4;1" dur="4s" begin={`${i * 0.35}s`} repeatCount="indefinite" />
        </rect>
      ))}
      <text x="296" y="238" fill={C1} fontSize="30" fontFamily="monospace" opacity=".8">{"</>"}</text>
    </g>
  );
}
function Ai() {
  const outer = Array.from({ length: 8 }, (_, i) => [200 + Math.cos((i / 8) * 6.283) * 105, 150 + Math.sin((i / 8) * 6.283) * 95] as const);
  const mid = Array.from({ length: 5 }, (_, i) => [200 + Math.cos((i / 5) * 6.283 + 0.4) * 55, 150 + Math.sin((i / 5) * 6.283 + 0.4) * 50] as const);
  return (
    <g>
      <circle cx="200" cy="150" r="60" fill="url(#sv-r)" />
      {mid.map(([x, y], i) => outer.filter((_, j) => j % 5 === i % 5 || j === i).map(([ox, oy], k) => (
        <line key={`${i}-${k}`} x1={x} y1={y} x2={ox} y2={oy} stroke={C2} strokeOpacity=".4" />
      )))}
      {mid.map(([x, y], i) => (
        <line key={`c${i}`} x1="200" y1="150" x2={x} y2={y} stroke={C1} strokeOpacity=".6" />
      ))}
      {outer.map(([x, y], i) => (
        <circle key={`o${i}`} cx={x} cy={y} r="5" fill="#000" stroke={C3} strokeWidth="1.5" />
      ))}
      {mid.map(([x, y], i) => (
        <circle key={`m${i}`} cx={x} cy={y} r="6" fill="#000" stroke={C1} strokeWidth="1.5" />
      ))}
      <circle cx="200" cy="150" r="14" fill="#fff" style={{ filter: `drop-shadow(0 0 14px ${C1})` }}>
        <animate attributeName="r" values="12;17;12" dur="2.4s" repeatCount="indefinite" />
      </circle>
      <Travel path={`M200 150 L${mid[0][0]} ${mid[0][1]} L${outer[0][0]} ${outer[0][1]}`} dur={2.2} color={C1} />
      <Travel path={`M200 150 L${mid[2][0]} ${mid[2][1]} L${outer[2][0]} ${outer[2][1]}`} dur={2.8} color={C3} begin="0.8s" />
    </g>
  );
}
function Mobile() {
  return (
    <g>
      <rect x="140" y="30" width="120" height="240" rx="22" {...S} strokeWidth="2" />
      <rect x="180" y="38" width="40" height="7" rx="3.5" fill={C1} opacity=".6" />
      <clipPath id="sv-phone">
        <rect x="148" y="54" width="104" height="206" rx="12" />
      </clipPath>
      <g clipPath="url(#sv-phone)">
        <g>
          <animateTransform attributeName="transform" type="translate" values="0 0;0 -70;0 0" dur="6s" repeatCount="indefinite" />
          {[0, 1, 2, 3, 4].map((i) => (
            <rect key={i} x="156" y={62 + i * 54} width="88" height="44" rx="10" fill={[C1, C2, C3][i % 3]} fillOpacity=".15" stroke={[C1, C2, C3][i % 3]} strokeOpacity=".8" />
          ))}
        </g>
      </g>
      <circle cx="60" cy="90" r="22" {...S} opacity=".5" />
      <circle cx="340" cy="210" r="30" {...S} opacity=".5" />
    </g>
  );
}
function Cloud() {
  return (
    <g>
      <ellipse cx="200" cy="150" rx="150" ry="40" {...S} opacity=".35" />
      <ellipse cx="200" cy="150" rx="110" ry="28" {...S} opacity=".35" />
      <path d="M130 170a30 30 0 0 1 4-60 40 40 0 0 1 76-8 34 34 0 0 1 56 26 28 28 0 0 1-6 42Z" {...S} fill={C2} fillOpacity=".12" strokeWidth="2" />
      <Travel path="M50 150a150 40 0 1 0 300 0a150 40 0 1 0 -300 0" dur={7} color={C1} />
      <Travel path="M90 150a110 28 0 1 0 220 0a110 28 0 1 0 -220 0" dur={5} color={C3} r={3} />
      <path d="M200 215V130M180 150l20-20 20 20" {...S} opacity=".9" />
    </g>
  );
}
function Security() {
  return (
    <g>
      <path d="M200 38 316 80V150c0 62-48 100-116 124C132 250 84 212 84 150V80Z" {...S} fill={C2} fillOpacity=".08" strokeWidth="2" />
      <path d="M150 156l36 36 66-74" {...S} strokeWidth="5" pathLength="1" strokeDasharray="1" strokeDashoffset="0">
        <animate attributeName="stroke-dashoffset" values="1;0;0;1" keyTimes="0;0.35;0.8;1" dur="4s" repeatCount="indefinite" />
      </path>
      <clipPath id="sv-shield">
        <path d="M200 38 316 80V150c0 62-48 100-116 124C132 250 84 212 84 150V80Z" />
      </clipPath>
      <g clipPath="url(#sv-shield)">
        <rect x="80" y="40" width="240" height="26" fill={C1} fillOpacity=".25" style={{ animation: "scan 3.2s ease-in-out infinite" }} />
      </g>
    </g>
  );
}
function Uiux() {
  return (
    <g>
      <path d="M60 220C110 60 180 280 230 140S320 60 340 90" {...S} strokeWidth="2.5" />
      {[[60, 220], [230, 140], [340, 90]].map(([x, y], i) => (
        <g key={i}>
          <rect x={x - 6} y={y - 6} width="12" height="12" fill="#000" stroke={C1} strokeWidth="1.5" />
        </g>
      ))}
      <path d="M230 140l50-60M230 140l-46 62" stroke={C3} strokeOpacity=".8" strokeDasharray="3 3" />
      <circle cx="280" cy="80" r="5" fill={C3} />
      <circle cx="184" cy="202" r="5" fill={C3} />
      <rect x="150" y="100" width="160" height="110" rx="4" fill="none" stroke={C1} strokeDasharray="4 4" opacity=".6" />
      {[C1, C2, C3].map((c, i) => (
        <circle key={c} cx={80 + i * 26} cy="258" r="9" fill={c} />
      ))}
      <Travel path="M60 220C110 60 180 280 230 140S320 60 340 90" dur={4} color="#fff" />
    </g>
  );
}
function ThreeDCube() {
  return (
    <div className="flex h-full w-full items-center justify-center" style={{ perspective: 700 }} role="img" aria-label="Rotating 3D cube">
      <div style={{ width: 110, height: 110, position: "relative", transformStyle: "preserve-3d", animation: "cube 9s linear infinite" }}>
        {["rotateY(0deg)", "rotateY(90deg)", "rotateY(180deg)", "rotateY(270deg)", "rotateX(90deg)", "rotateX(-90deg)"].map((t) => (
          <div key={t} className="cube-face" style={{ transform: `${t} translateZ(55px)` }} />
        ))}
      </div>
    </div>
  );
}
function Automation() {
  const nodes = [
    { x: 70, y: 150, c: C1, l: "TRIGGER" },
    { x: 200, y: 80, c: C3, l: "AI STEP" },
    { x: 200, y: 220, c: C2, l: "FILTER" },
    { x: 330, y: 150, c: C1, l: "ACTION" },
  ];
  const p1 = "M70 150C130 150 140 80 200 80C260 80 270 150 330 150";
  const p2 = "M70 150C130 150 140 220 200 220C260 220 270 150 330 150";
  return (
    <g>
      <path d={p1} {...S} opacity=".7" />
      <path d={p2} {...S} opacity=".7" />
      {nodes.map((n) => (
        <g key={n.l}>
          <rect x={n.x - 38} y={n.y - 18} width="76" height="36" rx="10" fill="#02060f" stroke={n.c} strokeWidth="1.5" />
          <text x={n.x} y={n.y + 4} textAnchor="middle" fill="#fff" fontSize="9" letterSpacing="2" fontFamily="monospace">
            {n.l}
          </text>
        </g>
      ))}
      <Travel path={p1} dur={3} color={C1} />
      <Travel path={p2} dur={3} color={C3} begin="1.5s" />
    </g>
  );
}

const MAP: Record<string, () => React.JSX.Element> = {
  web: Web, fullstack: Fullstack, software: Software, ai: Ai, mobile: Mobile,
  cloud: Cloud, security: Security, uiux: Uiux, automation: Automation,
};

export default function ServiceVisual({ id }: { id: string }) {
  if (id === "3d") return <ThreeDCube />;
  const V = MAP[id] ?? Web;
  return (
    <svg viewBox="0 0 400 300" className="h-full w-full" role="img" aria-label={`${id} illustration`}>
      <Glow />
      <V />
    </svg>
  );
}
