import { useRef, useState } from "react";
import { AnimatePresence, motion, useMotionTemplate, useMotionValue, useSpring, useTransform } from "framer-motion";
import { TECH_CATEGORIES } from "../data/techs";
import type { Tech } from "../data/techs";
import { TechLogo, brandColor } from "./TechLogo";

function Panel({ tech, i }: { tech: Tech; i: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const rx = useSpring(useTransform(my, [0, 1], [14, -14]), { stiffness: 220, damping: 20 });
  const ry = useSpring(useTransform(mx, [0, 1], [-14, 14]), { stiffness: 220, damping: 20 });
  const glare = useMotionTemplate`radial-gradient(circle at ${useTransform(mx, (v) => v * 100)}% ${useTransform(my, (v) => v * 100)}%, rgba(255,255,255,.22), transparent 55%)`;
  const color = brandColor(tech.icon);
  const [hover, setHover] = useState(false);

  const onMove = (e: React.PointerEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    mx.set((e.clientX - r.left) / r.width);
    my.set((e.clientY - r.top) / r.height);
  };
  const reset = () => {
    mx.set(0.5);
    my.set(0.5);
    setHover(false);
  };

  return (
    <motion.li
      initial={{ opacity: 0, y: 40, rotateX: -25 }}
      animate={{ opacity: 1, y: 0, rotateX: 0 }}
      exit={{ opacity: 0, y: -20, scale: 0.92 }}
      transition={{ duration: 0.6, delay: i * 0.05, ease: [0.2, 0.8, 0.2, 1] }}
      style={{ perspective: 900 }}
    >
      <div className="floaty" style={{ ["--d" as string]: `${(i % 5) * -1.1}s` }}>
        <motion.div
          ref={ref}
          onPointerMove={onMove}
          onPointerEnter={() => setHover(true)}
          onPointerLeave={reset}
          style={{
            rotateX: rx,
            rotateY: ry,
            transformStyle: "preserve-3d",
            boxShadow: hover
              ? `0 30px 80px -20px ${color}66, 0 0 0 1px ${color}88 inset`
              : "0 20px 50px -30px rgba(0,0,0,.9)",
          }}
          className="glass relative flex aspect-square flex-col items-center justify-center gap-4 overflow-hidden rounded-3xl transition-shadow duration-500"
          tabIndex={0}
          onFocus={() => setHover(true)}
          onBlur={reset}
        >
          <motion.div className="pointer-events-none absolute inset-0" style={{ background: glare, opacity: hover ? 1 : 0 }} />
          <div
            className="pointer-events-none absolute -bottom-10 left-1/2 h-24 w-3/4 -translate-x-1/2 rounded-full blur-2xl transition-opacity duration-500"
            style={{ background: color, opacity: hover ? 0.45 : 0.12 }}
          />
          <div style={{ transform: "translateZ(50px)" }} className="relative">
            <TechLogo icon={tech.icon} size={52} />
          </div>
          <span style={{ transform: "translateZ(30px)" }} className="mono relative !tracking-[0.12em] text-slate-200">
            {tech.name}
          </span>
        </motion.div>
      </div>
    </motion.li>
  );
}

export default function Technologies() {
  const [cat, setCat] = useState(TECH_CATEGORIES[0].id);
  const current = TECH_CATEGORIES.find((c) => c.id === cat)!;
  const total = TECH_CATEGORIES.reduce((n, c) => n + c.items.length, 0);

  return (
    <section id="technologies" className="relative overflow-hidden bg-[#01040d] px-5 py-28 sm:px-10 sm:py-36">
      <div
        className="pointer-events-none absolute inset-0 opacity-50"
        style={{
          backgroundImage:
            "linear-gradient(rgba(80,140,255,.07) 1px, transparent 1px), linear-gradient(90deg, rgba(80,140,255,.07) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage: "radial-gradient(ellipse at 50% 40%, #000 20%, transparent 75%)",
          WebkitMaskImage: "radial-gradient(ellipse at 50% 40%, #000 20%, transparent 75%)",
        }}
      />
      <div className="relative mx-auto max-w-[1500px]">
        <p className="mono section-label mb-8">TECHNOLOGY ARENA · 03</p>
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <h2 className="max-w-3xl text-[clamp(2rem,5vw,4.2rem)] font-light leading-[1.05] tracking-tight">
            Our <span className="chrome-text font-semibold">stack</span>, in orbit.
          </h2>
          <p className="mono text-slate-400">{total} TECHNOLOGIES · 8 DOMAINS</p>
        </div>

        <div role="tablist" aria-label="Technology categories" className="no-scrollbar mt-12 flex gap-2 overflow-x-auto pb-2">
          {TECH_CATEGORIES.map((c) => (
            <button
              key={c.id}
              role="tab"
              aria-selected={cat === c.id}
              onClick={() => setCat(c.id)}
              className={`mono shrink-0 rounded-full border px-5 py-3 transition-all ${cat === c.id ? "border-cyan-300 bg-cyan-300/10 text-white shadow-[0_0_30px_-8px_#38e1ff]" : "border-white/12 text-slate-400 hover:border-white/40 hover:text-white"}`}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="mt-10 flex items-baseline gap-4">
          <span className="blue-text text-5xl font-semibold">{String(current.items.length).padStart(2, "0")}</span>
          <p className="text-slate-300/80">{current.blurb}</p>
        </div>

        <AnimatePresence mode="wait">
          <motion.ul
            key={cat}
            role="tabpanel"
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:gap-6"
          >
            {current.items.map((t, i) => (
              <Panel key={t.name} tech={t} i={i} />
            ))}
          </motion.ul>
        </AnimatePresence>
      </div>
    </section>
  );
}
