import { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Link } from "react-router-dom";
import { PROJECTS } from "../data/projects";
import type { ProjectCategory } from "../data/projects";
import ProjectArt from "./ProjectArt";
import { TechLogo } from "./TechLogo";

const CATS: ("All" | ProjectCategory)[] = ["All", "AI", "3D Web", "Mobile", "Security", "Automation"];

export default function Projects() {
  const [cat, setCat] = useState<(typeof CATS)[number]>("All");
  const scroller = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);
  const drag = useRef({ down: false, x: 0, left: 0, moved: 0 });
  const list = PROJECTS.filter((p) => cat === "All" || p.category === cat);

  const onScroll = () => {
    const el = scroller.current;
    if (!el) return;
    const max = el.scrollWidth - el.clientWidth;
    setProgress(max > 0 ? el.scrollLeft / max : 0);
  };
  const by = (dir: number) =>
    scroller.current?.scrollBy({ left: dir * Math.min(560, window.innerWidth * 0.8), behavior: "smooth" });

  return (
    <section id="projects" className="relative overflow-hidden bg-[#01030a] py-28 sm:py-36">
      <div className="mx-auto max-w-[1500px] px-5 sm:px-10">
        <p className="mono section-label mb-8">PROJECTS · 05</p>
        <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
          <div>
            <h2 className="max-w-3xl text-[clamp(2rem,5vw,4.2rem)] font-light leading-[1.05] tracking-tight">
              The <span className="chrome-text font-semibold">showreel.</span>
            </h2>
            <p className="mt-4 max-w-xl text-slate-300/75">
              Original demo concepts built to show what we engineer. They are not client projects.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => by(-1)} aria-label="Previous projects" className="flex h-12 w-12 items-center justify-center rounded-full border border-white/20 transition hover:border-cyan-300 hover:bg-cyan-300/10">
              ←
            </button>
            <button onClick={() => by(1)} aria-label="Next projects" className="flex h-12 w-12 items-center justify-center rounded-full border border-white/20 transition hover:border-cyan-300 hover:bg-cyan-300/10">
              →
            </button>
          </div>
        </div>

        <div className="no-scrollbar mt-10 flex gap-2 overflow-x-auto" role="group" aria-label="Filter projects">
          {CATS.map((c) => (
            <button
              key={c}
              onClick={() => {
                setCat(c);
                scroller.current?.scrollTo({ left: 0 });
              }}
              aria-pressed={cat === c}
              className={`mono shrink-0 rounded-full border px-5 py-3 transition ${cat === c ? "border-cyan-300 bg-cyan-300/10 text-white" : "border-white/12 text-slate-400 hover:text-white"}`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      <div
        ref={scroller}
        onScroll={onScroll}
        onPointerDown={(e) => {
          if (e.pointerType !== "mouse") return;
          const el = scroller.current!;
          drag.current = { down: true, x: e.clientX, left: el.scrollLeft, moved: 0 };
        }}
        onPointerMove={(e) => {
          const d = drag.current;
          if (!d.down) return;
          d.moved = Math.abs(e.clientX - d.x);
          scroller.current!.scrollLeft = d.left - (e.clientX - d.x);
        }}
        onPointerUp={() => (drag.current.down = false)}
        onPointerLeave={() => (drag.current.down = false)}
        onClickCapture={(e) => {
          if (drag.current.moved > 6) {
            e.preventDefault();
            e.stopPropagation();
            drag.current.moved = 0;
          }
        }}
        className="no-scrollbar mt-12 flex cursor-grab snap-x snap-proximity gap-5 overflow-x-auto px-5 pb-6 active:cursor-grabbing sm:gap-7 sm:px-10 lg:px-[max(2.5rem,calc((100vw-1500px)/2+2.5rem))]"
        tabIndex={0}
        aria-label="Project showreel, scroll horizontally"
      >
        <AnimatePresence mode="popLayout">
          {list.map((p, i) => (
            <motion.div
              layout
              key={p.slug}
              initial={{ opacity: 0, x: 60 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.6, delay: i * 0.06 }}
              className="w-[80vw] shrink-0 snap-start sm:w-[440px]"
            >
              <Link
                to={`/project/${p.slug}`}
                draggable={false}
                className="group relative block aspect-[4/5] overflow-hidden rounded-[1.6rem] border border-white/10 transition-all duration-700 hover:-translate-y-2 hover:border-white/40"
                style={{ boxShadow: `0 40px 90px -50px ${p.accent}` }}
                aria-label={`${p.title} — ${p.kind}. View project`}
              >
                <div className="absolute inset-0 transition-transform duration-[1200ms] ease-out group-hover:scale-[1.12]">
                  <ProjectArt project={p} />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
                <span className="mono absolute left-5 top-5 rounded-full border border-white/25 bg-black/40 px-3 py-1.5 text-[0.6rem] backdrop-blur">
                  DEMO CONCEPT
                </span>
                <span className="mono absolute right-5 top-5 text-[0.62rem]" style={{ color: p.accent }}>
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div className="absolute inset-x-0 bottom-0 p-6 sm:p-7">
                  <p className="mono mb-2" style={{ color: p.accent }}>
                    {p.category} · {p.kind}
                  </p>
                  <h3 className="chrome-text text-4xl font-semibold tracking-wide sm:text-5xl">{p.title}</h3>
                  <div className="grid grid-rows-[0fr] transition-all duration-700 group-hover:grid-rows-[1fr] group-focus-visible:grid-rows-[1fr]">
                    <div className="overflow-hidden">
                      <p className="pt-3 text-slate-200/90">{p.tagline}</p>
                      <div className="mt-4 flex flex-wrap items-center gap-2">
                        {p.stack.slice(0, 5).map((t) => (
                          <span key={t.name} title={t.name} className="flex items-center gap-2 rounded-full border border-white/15 bg-black/40 px-3 py-1.5 backdrop-blur">
                            <TechLogo icon={t.icon} size={14} />
                            <span className="mono !text-[0.58rem] !tracking-[0.08em]">{t.name}</span>
                          </span>
                        ))}
                      </div>
                      <p className="mono mt-5 text-white">VIEW PROJECT →</p>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="mx-auto mt-4 max-w-[1500px] px-5 sm:px-10">
        <div className="h-px w-full bg-white/10">
          <div className="h-px bg-cyan-300 shadow-[0_0_10px_#38e1ff]" style={{ width: `${Math.max(12, progress * 100)}%` }} />
        </div>
        <p className="mono mt-4 text-slate-500">DRAG · SCROLL · HOVER TO PREVIEW</p>
      </div>
    </section>
  );
}
