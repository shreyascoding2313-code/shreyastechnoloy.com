import type { Project } from "../data/projects";

/** Generative, code-drawn cover art for the demo projects. Animations run on hover (see .art in CSS). */
export default function ProjectArt({ project, live = false }: { project: Project; live?: boolean }) {
  const a = project.accent;
  const b = project.accent2;
  const id = project.slug;
  const defs = (
    <defs>
      <linearGradient id={`${id}-g`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={a} />
        <stop offset="1" stopColor={b} />
      </linearGradient>
      <radialGradient id={`${id}-r`} cx="50%" cy="45%" r="60%">
        <stop offset="0" stopColor={b} stopOpacity=".55" />
        <stop offset=".6" stopColor={b} stopOpacity=".08" />
        <stop offset="1" stopColor="#000" stopOpacity="0" />
      </radialGradient>
      <linearGradient id={`${id}-f`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={a} stopOpacity=".5" />
        <stop offset="1" stopColor={a} stopOpacity="0" />
      </linearGradient>
    </defs>
  );
  const G = `url(#${id}-g)`;
  const origin = (x: number, y: number) => ({ transformOrigin: `${x}px ${y}px`, transformBox: "view-box" as const });

  let body: React.ReactNode = null;
  switch (id) {
    case "nebula-analytics":
      body = (
        <g>
          {[70, 120, 170, 220].map((r) => (
            <circle key={r} cx="200" cy="260" r={r} fill="none" stroke={a} strokeOpacity=".15" />
          ))}
          <path d="M20 360 L80 300 L130 330 L190 230 L250 270 L310 170 L380 120 V420 H20Z" fill={`url(#${id}-f)`} />
          <path d="M20 360 L80 300 L130 330 L190 230 L250 270 L310 170 L380 120" fill="none" stroke={G} strokeWidth="3" strokeLinecap="round" strokeDasharray="14 10" className="anim" style={{ animation: "dash 3s linear infinite" }} />
          {[[80, 300], [190, 230], [310, 170], [380, 120]].map(([x, y], i) => (
            <circle key={i} cx={x} cy={y} r="5" fill="#fff" className="anim" style={{ animation: `pulse-op 2s ${i * 0.3}s infinite` }} />
          ))}
          {[...Array(26)].map((_, i) => (
            <circle key={i} cx={30 + ((i * 53) % 340)} cy={40 + ((i * 97) % 150)} r={1 + (i % 3)} fill={b} opacity=".7" />
          ))}
        </g>
      );
      break;
    case "orbit-commerce":
      body = (
        <g>
          <circle cx="200" cy="210" r="95" fill={`url(#${id}-r)`} />
          <circle cx="200" cy="210" r="62" fill="#050818" stroke={G} strokeWidth="2" />
          <ellipse cx="170" cy="180" rx="22" ry="14" fill="#fff" opacity=".25" />
          {[130, 170, 210].map((rx, i) => (
            <g key={rx} className="anim" style={{ ...origin(200, 210), animation: `${i % 2 ? "spinrev" : "spin"} ${10 + i * 5}s linear infinite` }}>
              <ellipse cx="200" cy="210" rx={rx} ry={rx * 0.32} fill="none" stroke={G} strokeOpacity=".75" transform="rotate(-18 200 210)" />
              <circle cx={200 + rx} cy="210" r="5" fill="#fff" transform="rotate(-18 200 210)" />
            </g>
          ))}
          {[...Array(20)].map((_, i) => (
            <circle key={i} cx={(i * 71) % 400} cy={(i * 43) % 420} r="1.3" fill="#fff" opacity=".55" />
          ))}
        </g>
      );
      break;
    case "pulse-fitness":
      body = (
        <g>
          <circle cx="200" cy="190" r="100" fill={`url(#${id}-r)`} />
          {[
            [100, a, 0.78],
            [74, b, 0.55],
            [48, "#8b6cff", 0.9],
          ].map(([r, c, p], i) => {
            const circ = 2 * Math.PI * (r as number);
            return (
              <g key={i} style={origin(200, 190)} transform="rotate(-90 200 190)">
                <circle cx="200" cy="190" r={r as number} fill="none" stroke={c as string} strokeOpacity=".18" strokeWidth="16" />
                <circle cx="200" cy="190" r={r as number} fill="none" stroke={c as string} strokeWidth="16" strokeLinecap="round" strokeDasharray={`${circ * (p as number)} ${circ}`} className="anim" style={{ animation: `pulse-op 2.4s ${i * 0.4}s infinite` }} />
              </g>
            );
          })}
          <path d="M0 340 H110 L130 300 L160 380 L185 320 L205 340 H400" fill="none" stroke={G} strokeWidth="2.5" strokeDasharray="12 8" className="anim" style={{ animation: "dash 2.2s linear infinite" }} />
        </g>
      );
      break;
    case "vault-console":
      body = (
        <g>
          {[...Array(7)].map((_, r) =>
            [...Array(6)].map((_, c) => {
              const x = 30 + c * 66 + (r % 2) * 33;
              const y = 40 + r * 56;
              return <path key={`${r}${c}`} d={`M${x} ${y - 24} l21 12 v24 l-21 12 l-21 -12 v-24Z`} fill="none" stroke={a} strokeOpacity={0.14 + ((r * c) % 3) * 0.08} />;
            })
          )}
          <path d="M200 100 L290 135 V215 C290 275 245 305 200 322 C155 305 110 275 110 215 V135Z" fill="#050a1c" stroke={G} strokeWidth="3" />
          <path d="M160 215 l30 30 l55 -62" fill="none" stroke="#fff" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
          <rect x="100" y="110" width="200" height="30" fill={a} opacity=".25" className="anim" style={{ animation: "scan 2.6s ease-in-out infinite" }} />
        </g>
      );
      break;
    case "flowstate-automation": {
      const nodes = [[90, 120], [210, 90], [310, 200], [150, 250], [250, 330]];
      body = (
        <g>
          <circle cx="200" cy="210" r="130" fill={`url(#${id}-r)`} />
          {[[0, 1], [1, 2], [0, 3], [3, 2], [2, 4], [3, 4]].map(([x, y], i) => (
            <path key={i} d={`M${nodes[x][0]} ${nodes[x][1]} C${nodes[x][0] + 60} ${nodes[x][1]} ${nodes[y][0] - 60} ${nodes[y][1]} ${nodes[y][0]} ${nodes[y][1]}`} fill="none" stroke={G} strokeWidth="2" strokeDasharray="8 8" className="anim" style={{ animation: "dash 2.5s linear infinite" }} />
          ))}
          {nodes.map(([x, y], i) => (
            <g key={i}>
              <rect x={x - 34} y={y - 18} width="68" height="36" rx="10" fill="#060a1a" stroke={i % 2 ? b : a} strokeWidth="1.8" />
              <rect x={x - 22} y={y - 4} width={30 + (i % 3) * 8} height="8" rx="4" fill={i % 2 ? b : a} opacity=".8" className="anim" style={{ animation: `pulse-op 2s ${i * 0.3}s infinite` }} />
            </g>
          ))}
        </g>
      );
      break;
    }
    default:
      body = (
        <g>
          {[...Array(9)].map((_, i) => (
            <path key={i} d={`M${200 + (i - 4) * 14} 60 V 300`} stroke={G} strokeOpacity={0.35 - Math.abs(i - 4) * 0.05} strokeWidth="1.5" />
          ))}
          <g className="anim" style={{ ...origin(200, 190), animation: "spin 24s linear infinite" }}>
            <circle cx="200" cy="190" r="108" fill="none" stroke={G} strokeWidth="2" strokeDasharray="2 10" />
          </g>
          <circle cx="200" cy="190" r="86" fill="none" stroke={G} strokeWidth="6" style={{ filter: `drop-shadow(0 0 14px ${a})` }} />
          <circle cx="200" cy="190" r="60" fill={`url(#${id}-r)`} />
          {[...Array(10)].map((_, i) => (
            <path key={i} d={`M${-40 + i * 52} 420 L200 300`} stroke={a} strokeOpacity=".3" />
          ))}
          {[310, 340, 380].map((y) => (
            <path key={y} d={`M0 ${y} H400`} stroke={a} strokeOpacity=".22" />
          ))}
        </g>
      );
  }

  return (
    <svg viewBox="0 0 400 420" preserveAspectRatio="xMidYMid slice" className={`art h-full w-full ${live ? "live" : ""}`} aria-hidden="true">
      {defs}
      <rect width="400" height="420" fill="#02040c" />
      <rect width="400" height="420" fill={`url(#${id}-r)`} opacity=".5" />
      {body}
    </svg>
  );
}
