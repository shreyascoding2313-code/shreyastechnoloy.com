import { Component } from "react";
import type { ReactNode } from "react";

/** Catches WebGL / render failures and shows a lightweight CSS fallback instead of a blank screen. */
export class WebGLBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(err: unknown) {
    console.warn("3D scene failed, using fallback", err);
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

export function FallbackOrb({ className = "" }: { className?: string }) {
  return (
    <div className={`relative flex items-center justify-center ${className}`} aria-hidden="true">
      <div
        className="absolute h-[46vmin] w-[46vmin] rounded-full opacity-90"
        style={{
          background:
            "radial-gradient(circle at 32% 28%, #bfeaff 0%, #2f7bff 24%, #0a2a88 55%, #02040f 78%)",
          boxShadow: "0 0 120px 20px rgba(47,123,255,.45), inset -30px -40px 80px rgba(0,0,0,.6)",
        }}
      />
      <div
        className="absolute h-[64vmin] w-[64vmin] rounded-full border border-cyan-300/40"
        style={{ transform: "rotateX(70deg)", animation: "spin 12s linear infinite" }}
      />
    </div>
  );
}
