import { Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState } from "react";
import gsap from "gsap";
import { ctl, PRESETS, detectQuality, hasWebGL, prefersReducedMotion, useInView } from "../lib/store";
import { FallbackOrb, WebGLBoundary } from "./WebGLBoundary";
import { useScroll } from "../lib/scroll";

const ArenaCanvas = lazy(() => import("../three/Arena"));

export default function Hero({ ready }: { ready: boolean }) {
  const { goTo, lock, unlock } = useScroll();
  const quality = useMemo(detectQuality, []);
  const webgl = useMemo(hasWebGL, []);
  const [sectionRef, inView] = useInView<HTMLElement>("200px");
  const [arena, setArena] = useState(false);
  const [preset, setPreset] = useState(0);
  const [orbit, setOrbit] = useState(1);
  const text = useRef<HTMLDivElement>(null);
  const hud = useRef<HTMLDivElement>(null);
  const drag = useRef({ x: 0, y: 0 });

  // Entrance choreography once the intro has revealed the page
  useEffect(() => {
    if (!ready || !text.current) return;
    const ctx = gsap.context(() => {
      const q = gsap.utils.selector(text.current);
      if (prefersReducedMotion()) {
        gsap.set(q("[data-in]"), { opacity: 1, y: 0 });
        return;
      }
      gsap.fromTo(
        q("[data-in]"),
        { opacity: 0, y: 50, filter: "blur(12px)" },
        { opacity: 1, y: 0, filter: "blur(0px)", duration: 1.4, stagger: 0.12, ease: "power4.out", delay: 0.15 }
      );
    }, text);
    return () => ctx.revert();
  }, [ready]);

  const enterArena = useCallback(() => {
    setArena(true);
    lock();
    window.scrollTo({ top: 0 });
    gsap.to(ctl, { arena: 1, duration: 2, ease: "power3.inOut" });
    gsap.to(text.current, { autoAlpha: 0, y: -40, duration: 0.8, ease: "power2.in" });
    gsap.fromTo(hud.current, { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 1, delay: 1.0, ease: "power3.out" });
  }, [lock]);

  const exitArena = useCallback(() => {
    gsap.to(ctl, { arena: 0, duration: 1.6, ease: "power3.inOut" });
    gsap.to(hud.current, { opacity: 0, y: 30, duration: 0.5 });
    gsap.to(text.current, { autoAlpha: 1, y: 0, duration: 1, delay: 0.7, ease: "power3.out" });
    window.setTimeout(() => setArena(false), 500);
    unlock();
  }, [unlock]);

  useEffect(() => {
    if (!arena) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && exitArena();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [arena, exitArena]);

  useEffect(() => {
    ctl.preset = preset;
  }, [preset]);
  useEffect(() => {
    ctl.orbit = orbit;
  }, [orbit]);
  useEffect(
    () => () => {
      ctl.arena = 0;
      ctl.rotX = 0;
      ctl.rotY = 0;
      ctl.orbit = 1;
      unlock();
    },
    [unlock]
  );

  const down = (e: React.PointerEvent) => {
    if (!arena) return;
    ctl.dragging = true;
    drag.current = { x: e.clientX, y: e.clientY };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const move = (e: React.PointerEvent) => {
    if (!ctl.dragging) return;
    ctl.rotY += (e.clientX - drag.current.x) * 0.009;
    ctl.rotX = Math.max(-0.9, Math.min(0.9, ctl.rotX + (e.clientY - drag.current.y) * 0.006));
    drag.current = { x: e.clientX, y: e.clientY };
  };
  const up = () => {
    ctl.dragging = false;
  };

  return (
    <section
      id="home"
      ref={sectionRef}
      className="relative h-[100svh] min-h-[640px] w-full overflow-hidden bg-black"
      aria-label="SHREYAS TECHNOLOGIES — hero"
    >
      {/* 3D arena */}
      <div
        className={`absolute inset-0 ${arena ? "cursor-grab active:cursor-grabbing" : ""}`}
        style={{ touchAction: arena ? "none" : "pan-y" }}
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={up}
      >
        {ready &&
          (webgl ? (
            <WebGLBoundary fallback={<FallbackOrb className="h-full w-full" />}>
              <Suspense fallback={null}>
                <ArenaCanvas mode="hero" quality={quality} active={inView} preset={preset} />
              </Suspense>
            </WebGLBoundary>
          ) : (
            <FallbackOrb className="h-full w-full" />
          ))}
      </div>

      {/* legibility gradient */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "linear-gradient(90deg, rgba(0,0,0,.78) 0%, rgba(0,0,0,.35) 45%, transparent 70%), linear-gradient(0deg, rgba(0,0,0,.85) 0%, transparent 38%)",
          opacity: arena ? 0 : 1,
          transition: "opacity 1s",
        }}
      />

      {/* Typography */}
      <div
        ref={text}
        className="pointer-events-none relative z-10 mx-auto flex h-full max-w-[1500px] flex-col justify-end px-5 pb-10 pt-28 sm:px-10 sm:pb-14 lg:justify-center lg:pb-10"
      >
        <p data-in className="mono mb-5 flex items-center gap-4 text-sky-300 opacity-0">
          <span className="h-px w-10 bg-sky-300/70" /> ENTER THE FUTURE.
        </p>
        <h1 className="leading-[0.86]">
          <span data-in className="chrome-text block text-[clamp(3.4rem,13.5vw,10.5rem)] font-semibold tracking-[-0.02em] opacity-0">
            SHREYAS
          </span>
          <span data-in className="outline-text block text-[clamp(1.6rem,6.6vw,5.6rem)] font-extralight tracking-[0.06em] opacity-0">
            TECHNOLOGIES
          </span>
        </h1>
        <div className="mt-8 grid items-end gap-8 lg:mt-10 lg:grid-cols-[minmax(0,34rem)_auto] lg:gap-14">
          <div>
            <h2 data-in className="text-[clamp(1.05rem,2.1vw,1.7rem)] font-light leading-snug tracking-wide text-white opacity-0">
              WE DON'T FOLLOW THE FUTURE.
              <br />
              <span className="blue-text font-semibold">WE ENGINEER IT.</span>
            </h2>
            <p data-in className="mt-4 max-w-md text-[0.95rem] leading-relaxed text-slate-300/80 opacity-0">
              Intelligent software. Extraordinary experiences. Limitless possibilities.
            </p>
          </div>
          <div data-in className="pointer-events-auto flex flex-wrap gap-3 opacity-0">
            <button className="btn btn-primary" onClick={enterArena}>
              Explore the arena
            </button>
            <button className="btn btn-ghost" onClick={() => goTo("contact")}>
              Start a project
            </button>
          </div>
        </div>
      </div>

      {/* scroll cue */}
      {!arena && ready && (
        <div className="mono pointer-events-none absolute bottom-5 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-slate-400/70 lg:flex">
          SCROLL
          <span className="h-8 w-px bg-gradient-to-b from-cyan-300 to-transparent" />
        </div>
      )}

      {/* Arena HUD */}
      <div
        ref={hud}
        className="pointer-events-none absolute inset-x-0 bottom-0 z-20 opacity-0"
        style={{ visibility: arena ? "visible" : "hidden" }}
      >
        <div className="mx-auto flex max-w-[1500px] flex-col items-stretch gap-5 px-5 pb-8 sm:px-10 md:flex-row md:items-end md:justify-between">
          <div className="pointer-events-auto glass rounded-2xl p-5">
            <p className="mono mb-3 text-sky-300">THE ARENA · DRAG TO ROTATE</p>
            <div className="flex flex-wrap gap-2" role="group" aria-label="Glass tint">
              {PRESETS.map((p, i) => (
                <button
                  key={p.name}
                  onClick={() => setPreset(i)}
                  aria-pressed={preset === i}
                  className={`mono flex items-center gap-2 rounded-full border px-4 py-2 transition ${preset === i ? "border-white bg-white/10 text-white" : "border-white/15 text-slate-300 hover:border-white/50"}`}
                >
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: p.glow, boxShadow: `0 0 10px ${p.glow}` }} />
                  {p.name}
                </button>
              ))}
            </div>
            <label className="mono mt-4 flex items-center gap-4 text-slate-300">
              ORBIT SPEED
              <input
                type="range"
                min={0}
                max={4}
                step={0.1}
                value={orbit}
                onChange={(e) => setOrbit(parseFloat(e.target.value))}
                className="w-40"
                aria-label="Orbit speed"
              />
            </label>
          </div>
          <button className="btn btn-ghost pointer-events-auto self-start md:self-end" onClick={exitArena}>
            ← Exit arena (Esc)
          </button>
        </div>
      </div>
    </section>
  );
}
