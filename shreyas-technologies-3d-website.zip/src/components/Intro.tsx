import { Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState } from "react";
import gsap from "gsap";
import { LogoMark } from "./Logo";
import { FallbackOrb, WebGLBoundary } from "./WebGLBoundary";
import { INTRO_KEY, detectQuality, hasWebGL } from "../lib/store";
import { useScroll } from "../lib/scroll";

const ArenaCanvas = lazy(() => import("../three/Arena"));

export default function Intro({ onReveal, onDone }: { onReveal: () => void; onDone: () => void }) {
  const { lock, unlock } = useScroll();
  const quality = useMemo(detectQuality, []);
  const webgl = useMemo(hasWebGL, []);
  const [active, setActive] = useState(true);
  const root = useRef<HTMLDivElement>(null);
  const glow = useRef<HTMLDivElement>(null);
  const logo = useRef<HTMLDivElement>(null);
  const tag = useRef<HTMLDivElement>(null);
  const canvasWrap = useRef<HTMLDivElement>(null);
  const flash = useRef<HTMLDivElement>(null);
  const skip = useRef<HTMLButtonElement>(null);
  const tl = useRef<gsap.core.Timeline | null>(null);
  const finished = useRef(false);
  const emerge = useRef({ v: 0 }).current;
  const cam = useRef({ z: 16 }).current;

  const finish = useCallback(
    (fast: boolean) => {
      if (finished.current) return;
      finished.current = true;
      tl.current?.kill();
      onReveal();
      try {
        localStorage.setItem(INTRO_KEY, "1");
      } catch {
        /* storage unavailable */
      }
      if (fast) gsap.to(flash.current, { opacity: 0.55, duration: 0.25 });
      gsap.to(root.current, {
        opacity: 0,
        duration: fast ? 0.6 : 1.2,
        ease: "power2.inOut",
        onComplete: onDone,
      });
      window.setTimeout(() => setActive(false), 250);
    },
    [onDone, onReveal]
  );

  useEffect(() => {
    lock();
    const letters = logo.current?.querySelectorAll("[data-l]") ?? [];
    const ctx = gsap.context(() => {
      const t = gsap.timeline({ defaults: { ease: "power3.out" } });
      tl.current = t;
      gsap.set([logo.current, tag.current], { opacity: 1 });
      gsap.set(canvasWrap.current, { opacity: 0 });
      t.fromTo(glow.current, { scale: 0.15, opacity: 0 }, { scale: 1, opacity: 1, duration: 2.2, ease: "power2.out" }, 0.2)
        .fromTo(skip.current, { opacity: 0 }, { opacity: 1, duration: 0.6 }, 0.4)
        .fromTo(
          letters,
          { opacity: 0, y: 24, filter: "blur(16px)" },
          { opacity: 1, y: 0, filter: "blur(0px)", duration: 1.0, stagger: 0.045 },
          0.7
        )
        .to(canvasWrap.current, { opacity: 1, duration: 1.4, ease: "power2.inOut" }, 1.9)
        .to(emerge, { v: 1, duration: 2.6, ease: "power3.out" }, 1.9)
        .to(cam, { z: 7.6, duration: 3.0, ease: "power2.inOut" }, 1.5)
        .to(logo.current, { y: "-37vh", scale: 0.5, duration: 1.4, ease: "power3.inOut" }, 2.1)
        .fromTo(tag.current, { opacity: 0, y: 16, letterSpacing: "0.9em" }, { opacity: 1, y: 0, letterSpacing: "0.5em", duration: 1.4 }, 3.1)
        .to(cam, { z: 5.0, duration: 1.1, ease: "power2.in" }, 4.4)
        .to(flash.current, { opacity: 1, duration: 0.6, ease: "power2.in" }, 4.9)
        .call(onReveal, [], 5.0)
        .call(() => setActive(false), [], 5.55)
        .call(() => finish(false), [], 5.6);
    }, root);

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === "Enter") finish(true);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      ctx.revert();
      unlock();
    };
  }, [finish, onReveal, emerge, cam, lock, unlock]);

  const word = "SHREYAS";
  return (
    <div
      ref={root}
      role="dialog"
      aria-label="SHREYAS TECHNOLOGIES intro"
      className="fixed inset-0 z-[100] overflow-hidden bg-black"
    >
      <div
        ref={glow}
        className="pointer-events-none absolute left-1/2 top-1/2 h-[120vmax] w-[120vmax] -translate-x-1/2 -translate-y-1/2 opacity-0"
        style={{
          background:
            "radial-gradient(circle, rgba(47,123,255,.55) 0%, rgba(20,60,200,.22) 18%, rgba(4,12,60,.1) 38%, transparent 60%)",
        }}
      />

      <div ref={canvasWrap} className="absolute inset-0 opacity-0">
        {webgl ? (
          <WebGLBoundary fallback={<FallbackOrb className="h-full w-full" />}>
            <Suspense fallback={null}>
              <ArenaCanvas mode="intro" quality={quality} active={active} emerge={emerge} cam={cam} />
            </Suspense>
          </WebGLBoundary>
        ) : (
          <FallbackOrb className="h-full w-full" />
        )}
      </div>

      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
        <div ref={logo} className="flex flex-col items-center opacity-0">
          <span data-l>
            <LogoMark size={72} />
          </span>
          <div className="mt-6 flex" aria-label="SHREYAS TECHNOLOGIES">
            {word.split("").map((c, i) => (
              <span key={i} data-l className="chrome-text text-[clamp(2.2rem,8vw,5.5rem)] font-semibold tracking-[0.12em]">
                {c}
              </span>
            ))}
          </div>
          <div className="flex">
            {"TECHNOLOGIES".split("").map((c, i) => (
              <span key={i} data-l className="mono text-[clamp(0.7rem,1.8vw,1.15rem)] tracking-[0.55em] text-sky-300">
                {c}
              </span>
            ))}
          </div>
        </div>
        <div
          ref={tag}
          className="mono absolute bottom-[14vh] text-[clamp(0.7rem,1.6vw,1rem)] tracking-[0.5em] text-white opacity-0"
        >
          ENTER THE FUTURE.
        </div>
      </div>

      <div
        ref={flash}
        className="pointer-events-none absolute inset-0 opacity-0"
        style={{ background: "radial-gradient(circle at 50% 50%, #cfe6ff 0%, #2f7bff 35%, #02061c 80%)" }}
      />

      <button
        ref={skip}
        onClick={() => finish(true)}
        className="mono absolute right-5 top-5 z-10 rounded-full border border-white/25 bg-white/5 px-5 py-3 text-white opacity-0 backdrop-blur transition hover:border-cyan-300 hover:bg-cyan-300/10 sm:right-10 sm:top-8"
      >
        Skip intro →
      </button>
    </div>
  );
}
