import { Wordmark } from "./Logo";
import { NAV } from "./Nav";
import { useScroll } from "../lib/scroll";
import { CONTACT_EMAIL } from "./Contact";

export default function Footer({ onReplay }: { onReplay: () => void }) {
  const { goTo } = useScroll();
  return (
    <footer className="relative border-t border-white/10 bg-black px-5 pb-10 pt-16 sm:px-10">
      <div className="mx-auto max-w-[1500px]">
        <div className="grid gap-12 md:grid-cols-[1.2fr_1fr_1fr]">
          <div>
            <Wordmark />
            <p className="mono mt-6 !tracking-[0.3em] text-sky-300">ENTER THE FUTURE.</p>
          </div>
          <nav aria-label="Footer">
            <ul className="grid grid-cols-2 gap-3">
              {NAV.map((n) => (
                <li key={n.id}>
                  <a
                    href="#/"
                    onClick={(e) => {
                      e.preventDefault();
                      goTo(n.id);
                    }}
                    className="mono text-slate-400 transition hover:text-white"
                  >
                    {n.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          <div>
            <p className="mono text-slate-500">EMAIL</p>
            <a href={`mailto:${CONTACT_EMAIL}`} className="mt-2 block break-all text-white underline decoration-cyan-300/40 underline-offset-4 hover:decoration-cyan-300">
              {CONTACT_EMAIL}
            </a>
            <button onClick={onReplay} className="mono mt-6 text-slate-400 transition hover:text-cyan-300">
              ↻ Replay intro
            </button>
          </div>
        </div>
        <div className="mt-14 flex flex-col justify-between gap-3 border-t border-white/10 pt-6 text-slate-500 sm:flex-row">
          <p className="mono !tracking-[0.12em]">© {new Date().getFullYear()} SHREYAS TECHNOLOGIES</p>
          <p className="mono !tracking-[0.12em]">Brand logos are trademarks of their respective owners.</p>
        </div>
      </div>
    </footer>
  );
}
