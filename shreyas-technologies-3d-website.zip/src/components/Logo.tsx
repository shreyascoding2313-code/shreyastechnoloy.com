import { useId } from "react";

export function LogoMark({ size = 36, glow = true }: { size?: number; glow?: boolean }) {
  const id = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      aria-hidden="true"
      style={glow ? { filter: "drop-shadow(0 0 10px rgba(47,123,255,.8))" } : undefined}
    >
      <defs>
        <linearGradient id={`${id}-g`} x1="8" y1="8" x2="56" y2="56" gradientUnits="userSpaceOnUse">
          <stop stopColor="#7ff3ff" />
          <stop offset="0.5" stopColor="#2f7bff" />
          <stop offset="1" stopColor="#8b6cff" />
        </linearGradient>
      </defs>
      <path
        d="M45 19c-3-5-10-7-16-5-7 2-9 9-4 13 5 3 12 3 14 8 2 6-5 10-12 8-4-1-7-4-8-7"
        stroke={`url(#${id}-g)`}
        strokeWidth="7"
        strokeLinecap="round"
      />
      <path
        d="M44 18.5c-3-4-9-6-15-4.2"
        stroke="#fff"
        strokeOpacity="0.55"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <ellipse cx="32" cy="32" rx="28" ry="10" stroke="#38e1ff" strokeOpacity="0.45" strokeWidth="1" transform="rotate(-28 32 32)" />
      <circle cx="54" cy="21" r="2.4" fill="#fff" />
    </svg>
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-3">
      <LogoMark size={compact ? 30 : 38} />
      <span className="flex flex-col leading-none">
        <span className="font-semibold tracking-[0.32em] text-white text-[0.95rem]">SHREYAS</span>
        <span className="mono mt-1 text-[0.55rem] tracking-[0.42em] text-sky-300/80">TECHNOLOGIES</span>
      </span>
    </span>
  );
}
