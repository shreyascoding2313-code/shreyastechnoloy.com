import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import type { MotionValue } from "framer-motion";

const STATEMENT =
  "We build digital worlds that feel inevitable — engineered with the precision of software and the emotion of cinema.";

function Word({ word, range, progress }: { word: string; range: [number, number]; progress: MotionValue<number> }) {
  const opacity = useTransform(progress, range, [0.14, 1]);
  return (
    <motion.span style={{ opacity }} className="mr-[0.28em] inline-block">
      {word}
    </motion.span>
  );
}

const PRINCIPLES = [
  { n: "01", t: "Engineering first", d: "Clean architecture, typed code, tested releases. Beauty never costs reliability." },
  { n: "02", t: "Motion with purpose", d: "Every transition explains something. Nothing moves just to move." },
  { n: "03", t: "Built to scale", d: "Performance budgets, accessibility and security are part of the brief from day one." },
];

const STEPS = ["DISCOVER", "DESIGN", "ENGINEER", "LAUNCH"];

export default function About() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 85%", "end 55%"] });
  const words = STATEMENT.split(" ");

  return (
    <section id="about" className="relative overflow-hidden bg-black px-5 py-28 sm:px-10 sm:py-40">
      <div
        className="pointer-events-none absolute -left-1/4 top-0 h-[60vh] w-[70vw] opacity-60"
        style={{ background: "radial-gradient(ellipse at center, rgba(30,70,220,.22), transparent 65%)" }}
      />
      <div className="relative mx-auto max-w-[1500px]">
        <p className="mono section-label mb-10">ABOUT · 01</p>
        <div ref={ref}>
          <h2 className="max-w-6xl text-[clamp(1.9rem,5.4vw,4.6rem)] font-light leading-[1.12] tracking-tight text-white">
            {words.map((w, i) => (
              <Word key={i} word={w} range={[i / words.length, (i + 1.5) / words.length]} progress={scrollYProgress} />
            ))}
          </h2>
        </div>

        <div className="mt-24 grid gap-12 md:grid-cols-3 md:gap-8">
          {PRINCIPLES.map((p, i) => (
            <motion.div
              key={p.n}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.8, delay: i * 0.12 }}
              className="border-t border-white/15 pt-6"
            >
              <span className="mono text-cyan-300">{p.n}</span>
              <h3 className="mt-4 text-2xl font-semibold text-white">{p.t}</h3>
              <p className="mt-3 max-w-sm leading-relaxed text-slate-300/75">{p.d}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-28">
          <p className="mono mb-8 text-slate-400">HOW WE WORK</p>
          <div className="relative grid grid-cols-2 gap-y-10 sm:grid-cols-4">
            <motion.div
              className="absolute left-0 top-[7px] hidden h-px origin-left bg-gradient-to-r from-cyan-300 via-blue-500 to-violet-500 sm:block"
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1.8, ease: "easeInOut" }}
              style={{ width: "100%" }}
            />
            {STEPS.map((s, i) => (
              <div key={s} className="relative">
                <span className="relative z-10 block h-3.5 w-3.5 rounded-full bg-cyan-300 shadow-[0_0_18px_#38e1ff]" />
                <p className="mono mt-5 text-white">
                  0{i + 1} · {s}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
