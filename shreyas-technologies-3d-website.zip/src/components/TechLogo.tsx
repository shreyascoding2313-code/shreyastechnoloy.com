import { ICONS } from "../data/iconPaths";

const OVERRIDE: Record<string, string> = { aws: "FF9900", openai: "74AA9C", chatgpt: "10A37F", spline: "FF5C9D" };

function lum(hex: string) {
  const n = parseInt(hex, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}
function lighten(hex: string, amt: number) {
  const n = parseInt(hex, 16);
  const mix = (c: number) => Math.round(c + (255 - c) * amt);
  const r = mix((n >> 16) & 255);
  const g = mix((n >> 8) & 255);
  const b = mix(n & 255);
  return `#${((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1)}`;
}

/** Brand colour that stays visible on a black background. */
export function brandColor(key: string): string {
  const raw = OVERRIDE[key] ?? ICONS[key]?.h ?? "FFFFFF";
  return lum(raw) < 0.32 ? lighten(raw, 0.75) : `#${raw}`;
}

export function TechLogo({ icon, size = 44, mono = false }: { icon: string; size?: number; mono?: boolean }) {
  const def = ICONS[icon];
  if (!def) return null;
  const color = mono ? "#dfeaff" : brandColor(icon);
  if (icon === "spline") {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path
          d="M17.5 6.2C16 3.6 7.2 3.4 7.2 8.4c0 5 10 2.6 10 7.9 0 5.1-9.2 5-10.9 1.6"
          stroke={color}
          strokeWidth="2.6"
          strokeLinecap="round"
        />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} aria-hidden="true">
      <path d={def.p} />
    </svg>
  );
}
