import { useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { SERVICES } from "../data/services";

export const CONTACT_EMAIL = "shreyascoding2313@gmail.com";

const BUDGETS = ["Under $1,000", "$1,000 – $5,000", "$5,000 – $15,000", "$15,000+", "Not sure yet"];
const SERVICE_OPTIONS = [...SERVICES.map((s) => s.title), "Something else"];

const SUPABASE_URL = (import.meta.env.VITE_SUPABASE_URL ?? "").replace(/\/$/, "");
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY ?? "";
const ENDPOINT = SUPABASE_URL ? `${SUPABASE_URL}/functions/v1/send-contact` : "";

interface Form {
  name: string;
  email: string;
  phone: string;
  service: string;
  budget: string;
  message: string;
  website: string; // honeypot
}
type Errors = Partial<Record<keyof Form, string>>;
type Status = "idle" | "sending" | "success" | "error" | "unconfigured";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function validate(f: Form): Errors {
  const e: Errors = {};
  if (f.name.trim().length < 2 || f.name.length > 100) e.name = "Please enter your full name (2–100 characters).";
  if (!EMAIL_RE.test(f.email.trim()) || f.email.length > 254) e.email = "Please enter a valid email address.";
  if (f.phone.trim() && !/^[+()\d\s.-]{7,20}$/.test(f.phone.trim())) e.phone = "Use 7–20 digits; + ( ) - are allowed.";
  if (!f.service) e.service = "Choose a service.";
  if (!f.budget) e.budget = "Choose a budget range.";
  if (f.message.trim().length < 20) e.message = "Tell us a little more (at least 20 characters).";
  if (f.message.length > 4000) e.message = "Please keep the description under 4000 characters.";
  return e;
}

export default function Contact() {
  const openedAt = useRef(Date.now());
  const [f, setF] = useState<Form>({ name: "", email: "", phone: "", service: "", budget: "", message: "", website: "" });
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [note, setNote] = useState("");

  const set = (k: keyof Form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setF((p) => ({ ...p, [k]: e.target.value }));
    if (errors[k]) setErrors((p) => ({ ...p, [k]: undefined }));
  };

  const mailto = useMemo(() => {
    const body = `Name: ${f.name}\nEmail: ${f.email}\nPhone: ${f.phone || "-"}\nService: ${f.service || "-"}\nBudget: ${f.budget || "-"}\n\n${f.message}`;
    return `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(`Project enquiry — ${f.service || "SHREYAS TECHNOLOGIES"}`)}&body=${encodeURIComponent(body)}`;
  }, [f]);

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (status === "sending") return;
    const errs = validate(f);
    setErrors(errs);
    if (Object.keys(errs).length) {
      setStatus("idle");
      return;
    }
    if (!ENDPOINT) {
      setStatus("unconfigured");
      return;
    }
    setStatus("sending");
    setNote("");
    const ctrl = new AbortController();
    const to = window.setTimeout(() => ctrl.abort(), 20000);
    try {
      const res = await fetch(ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(SUPABASE_KEY ? { apikey: SUPABASE_KEY } : {}) },
        body: JSON.stringify({ ...f, elapsedMs: Date.now() - openedAt.current }),
        signal: ctrl.signal,
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data?.ok === true && data?.id) {
        setStatus("success");
        setF({ name: "", email: "", phone: "", service: "", budget: "", message: "", website: "" });
        return;
      }
      if (res.status === 429) setNote("Too many enquiries from your connection. Please wait a while and try again.");
      else if (res.status === 400 && data?.errors) {
        setErrors(data.errors as Errors);
        setNote("Please check the highlighted fields.");
      } else if (res.status === 503 || data?.error === "not_configured") {
        setStatus("unconfigured");
        return;
      } else setNote(data?.message || "Your message could not be delivered. Please try again or email us directly.");
      setStatus("error");
    } catch (err) {
      setNote(
        (err as Error).name === "AbortError"
          ? "The request timed out. Your message was not confirmed as sent."
          : "Network error — your message was not sent."
      );
      setStatus("error");
    } finally {
      window.clearTimeout(to);
    }
  };

  const Err = ({ k }: { k: keyof Form }) =>
    errors[k] ? (
      <p id={`${k}-err`} role="alert" className="mt-2 text-sm text-rose-300">
        {errors[k]}
      </p>
    ) : null;
  const aria = (k: keyof Form) => ({ "aria-invalid": !!errors[k], "aria-describedby": errors[k] ? `${k}-err` : undefined });

  return (
    <section id="contact" className="relative overflow-hidden bg-black px-5 py-28 sm:px-10 sm:py-36">
      <div
        className="pointer-events-none absolute -bottom-1/4 left-1/2 h-[80vh] w-[120vw] -translate-x-1/2 opacity-70"
        style={{ background: "radial-gradient(ellipse at center, rgba(30,80,255,.28), transparent 62%)" }}
      />
      <div className="relative mx-auto grid max-w-[1500px] gap-16 lg:grid-cols-[0.85fr_1.15fr]">
        <div>
          <p className="mono section-label mb-8">CONTACT · 06</p>
          <h2 className="text-[clamp(2.4rem,6vw,5.4rem)] font-light leading-[0.98] tracking-tight">
            Let's build
            <br />
            <span className="chrome-text font-semibold">what's next.</span>
          </h2>
          <p className="mt-6 max-w-md leading-relaxed text-slate-300/80">
            Tell us about your idea. Every enquiry is read by the team and delivered straight to our inbox.
          </p>
          <a
            href={`mailto:${CONTACT_EMAIL}`}
            className="mt-10 inline-block break-all text-[clamp(1.1rem,2.4vw,1.7rem)] text-white underline decoration-cyan-300/50 underline-offset-8 transition hover:decoration-cyan-300"
          >
            {CONTACT_EMAIL}
          </a>
        </div>

        <div className="glass relative rounded-[2rem] p-6 sm:p-10">
          <AnimatePresence mode="wait">
            {status === "success" ? (
              <motion.div
                key="ok"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex min-h-[420px] flex-col items-start justify-center"
                role="status"
              >
                <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-full border border-cyan-300/60 text-2xl text-cyan-300 shadow-[0_0_40px_-6px_#38e1ff]">
                  ✓
                </div>
                <h3 className="text-3xl font-semibold">Message delivered.</h3>
                <p className="mt-3 max-w-md text-slate-300/80">
                  Your enquiry reached our inbox. We'll reply to the email address you provided.
                </p>
                <button className="btn btn-ghost mt-8" onClick={() => setStatus("idle")}>
                  Send another
                </button>
              </motion.div>
            ) : (
              <motion.form key="form" onSubmit={submit} noValidate initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid gap-x-8 gap-y-6 sm:grid-cols-2">
                <div>
                  <label className="mono text-slate-400" htmlFor="c-name">Full name</label>
                  <input id="c-name" className="field" autoComplete="name" maxLength={100} value={f.name} onChange={set("name")} placeholder="Ada Lovelace" {...aria("name")} />
                  <Err k="name" />
                </div>
                <div>
                  <label className="mono text-slate-400" htmlFor="c-email">Email</label>
                  <input id="c-email" type="email" className="field" autoComplete="email" maxLength={254} value={f.email} onChange={set("email")} placeholder="you@company.com" {...aria("email")} />
                  <Err k="email" />
                </div>
                <div>
                  <label className="mono text-slate-400" htmlFor="c-phone">Phone <span className="text-slate-600">(optional)</span></label>
                  <input id="c-phone" type="tel" className="field" autoComplete="tel" maxLength={20} value={f.phone} onChange={set("phone")} placeholder="+00 000 000 0000" {...aria("phone")} />
                  <Err k="phone" />
                </div>
                <div>
                  <label className="mono text-slate-400" htmlFor="c-service">Service</label>
                  <select id="c-service" className="field" value={f.service} onChange={set("service")} {...aria("service")}>
                    <option value="">Select a service</option>
                    {SERVICE_OPTIONS.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                  <Err k="service" />
                </div>
                <div className="sm:col-span-2">
                  <label className="mono text-slate-400" htmlFor="c-budget">Budget</label>
                  <select id="c-budget" className="field" value={f.budget} onChange={set("budget")} {...aria("budget")}>
                    <option value="">Select a range</option>
                    {BUDGETS.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                  <Err k="budget" />
                </div>
                <div className="sm:col-span-2">
                  <label className="mono text-slate-400" htmlFor="c-msg">Project description</label>
                  <textarea id="c-msg" rows={5} className="field resize-none" maxLength={4000} value={f.message} onChange={set("message")} placeholder="What are you building, and what should it feel like?" {...aria("message")} />
                  <div className="flex justify-between">
                    <Err k="message" />
                    <span className="mono ml-auto mt-2 !text-[0.6rem] text-slate-600">{f.message.length}/4000</span>
                  </div>
                </div>

                {/* honeypot: hidden from people, tempting for bots */}
                <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                  <label htmlFor="c-web">Website</label>
                  <input id="c-web" tabIndex={-1} autoComplete="off" value={f.website} onChange={set("website")} />
                </div>

                <div className="sm:col-span-2">
                  {status === "error" && (
                    <p role="alert" className="mb-5 rounded-xl border border-rose-400/40 bg-rose-500/10 p-4 text-sm text-rose-200">
                      {note} <a className="underline" href={mailto}>Email us directly</a>.
                    </p>
                  )}
                  {status === "unconfigured" && (
                    <div role="alert" className="mb-5 rounded-xl border border-amber-300/40 bg-amber-400/10 p-4 text-sm leading-relaxed text-amber-100">
                      <p className="font-semibold">Email delivery isn't connected yet — your message was NOT sent.</p>
                      <p className="mt-2 text-amber-100/80">
                        The site owner must deploy the <code>send-contact</code> Supabase Edge Function, add a
                        <code> RESEND_API_KEY</code> secret and set <code>VITE_SUPABASE_URL</code> (see
                        <code> SETUP_EMAIL.md</code>). Meanwhile you can send this enquiry from your own mail app:
                      </p>
                      <a href={mailto} className="btn btn-ghost mt-4 !py-3">Open in email app</a>
                    </div>
                  )}
                  <button type="submit" disabled={status === "sending"} className="btn btn-primary w-full disabled:opacity-60 sm:w-auto">
                    {status === "sending" ? (
                      <>
                        <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white/30 border-t-white" /> Sending…
                      </>
                    ) : (
                      "Send enquiry →"
                    )}
                  </button>
                  <p className="mt-4 text-xs text-slate-500">
                    Your details are used only to reply to this enquiry.
                  </p>
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
