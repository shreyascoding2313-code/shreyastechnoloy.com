import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { SERVICES } from "../data/services";
import ServiceVisual from "./ServiceVisuals";

function Detail({ i }: { i: number }) {
  const s = SERVICES[i];
  return (
    <div>
      <div className="relative aspect-[4/3] w-full overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-[#04102e] via-black to-[#0b0622]">
        <div
          className="pointer-events-none absolute inset-0 opacity-60"
          style={{ background: "radial-gradient(circle at 50% 60%, rgba(47,123,255,.25), transparent 65%)" }}
        />
        <span className="mono absolute left-5 top-5 text-sky-300/80">0{i + 1} / {SERVICES.length}</span>
        <AnimatePresence mode="wait">
          <motion.div
            key={s.id}
            initial={{ opacity: 0, scale: 0.94, filter: "blur(8px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
            exit={{ opacity: 0, scale: 1.04, filter: "blur(8px)" }}
            transition={{ duration: 0.45 }}
            className="absolute inset-0 p-8"
          >
            <ServiceVisual id={s.id} />
          </motion.div>
        </AnimatePresence>
      </div>
      <p className="mt-6 max-w-lg text-lg leading-relaxed text-slate-200/90">{s.line}</p>
      <ul className="mt-5 flex flex-wrap gap-2">
        {s.points.map((p) => (
          <li key={p} className="mono rounded-full border border-white/12 px-4 py-2 !tracking-[0.1em] text-slate-300">
            {p}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Services() {
  const [active, setActive] = useState(0);
  return (
    <section id="services" className="relative bg-black px-5 py-28 sm:px-10 sm:py-36">
      <div
        className="pointer-events-none absolute right-0 top-1/3 h-[70vh] w-[60vw] opacity-60"
        style={{ background: "radial-gradient(ellipse at center, rgba(110,70,255,.16), transparent 65%)" }}
      />
      <div className="relative mx-auto max-w-[1500px]">
        <p className="mono section-label mb-8">SERVICES · 02</p>
        <h2 className="max-w-4xl text-[clamp(2rem,5vw,4.2rem)] font-light leading-[1.05] tracking-tight">
          <span className="chrome-text font-semibold">Ten disciplines.</span> One engineering studio.
        </h2>

        <div className="mt-16 grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:gap-20">
          <ul className="divide-y divide-white/10 border-y border-white/10">
            {SERVICES.map((s, i) => {
              const on = i === active;
              return (
                <li key={s.id}>
                  <button
                    onMouseEnter={() => window.matchMedia("(hover: hover)").matches && setActive(i)}
                    onFocus={() => setActive(i)}
                    onClick={() => setActive(i)}
                    aria-expanded={on}
                    className="group flex w-full items-center gap-5 py-5 text-left sm:gap-8 sm:py-6"
                  >
                    <span className={`mono w-8 transition-colors ${on ? "text-cyan-300" : "text-slate-500"}`}>
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span
                      className={`flex-1 text-[clamp(1.3rem,3.2vw,2.5rem)] tracking-tight transition-all duration-500 ${on ? "translate-x-3 font-semibold text-white" : "font-extralight text-slate-400 group-hover:text-slate-200"}`}
                    >
                      {s.title}
                    </span>
                    <span
                      className={`text-2xl transition-all duration-500 ${on ? "translate-x-0 text-cyan-300 opacity-100" : "-translate-x-3 opacity-0"}`}
                      aria-hidden="true"
                    >
                      →
                    </span>
                  </button>
                  {/* mobile / tablet inline detail */}
                  <AnimatePresence initial={false}>
                    {on && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
                        className="overflow-hidden lg:hidden"
                      >
                        <div className="pb-8">
                          <Detail i={i} />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </li>
              );
            })}
          </ul>
          <div className="relative hidden lg:block">
            <div className="sticky top-28">
              <Detail i={active} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
