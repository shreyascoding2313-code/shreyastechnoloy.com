import { Suspense, lazy, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { AI_MODES, detectQuality, hasWebGL, useInView } from "../lib/store";
import { FallbackOrb, WebGLBoundary } from "./WebGLBoundary";

const AINetwork = lazy(() => import("../three/AINetwork"));

const CAPS = [
  { t: "AI-powered applications", d: "Products where intelligence is a feature users can feel — search, summaries, recommendations, assistants." },
  { t: "LLM integration", d: "Connect OpenAI, Gemini, Claude or open models to your product through secure, server-side APIs." },
  { t: "AI agents", d: "Agents that plan, call tools and complete multi-step tasks, with guardrails and human review." },
  { t: "Workflow automation", d: "Replace repetitive manual steps with orchestrated, observable pipelines." },
  { t: "Chatbots", d: "Conversational interfaces grounded in your own content and connected to a real model API." },
  { t: "Intelligent data processing", d: "Extract, classify and enrich documents and data at scale." },
];

export default function AILab() {
  const quality = useMemo(detectQuality, []);
  const webgl = useMemo(hasWebGL, []);
  const [ref, inView] = useInView<HTMLDivElement>("100px");
  const [mode, setMode] = useState(0);
  const burst = useRef(0);

  return (
    <section id="ai-lab" className="relative overflow-hidden bg-black px-5 py-28 sm:px-10 sm:py-36">
      <div className="relative mx-auto grid max-w-[1500px] gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <div>
          <p className="mono section-label mb-8">AI LAB · 04</p>
          <h2 className="text-[clamp(2.2rem,5.4vw,4.6rem)] font-light leading-[1.02] tracking-tight">
            Intelligence,
            <br />
            <span className="blue-text font-semibold">engineered in.</span>
          </h2>
          <p className="mt-6 max-w-lg leading-relaxed text-slate-300/80">
            We integrate language models and automation into products people use every day — carefully, securely and
            measurably.
          </p>
          <ul className="mt-10 divide-y divide-white/10 border-y border-white/10">
            {CAPS.map((c, i) => {
              const on = mode === i;
              return (
                <li key={c.t}>
                  <button
                    onClick={() => setMode(i)}
                    onMouseEnter={() => window.matchMedia("(hover: hover)").matches && setMode(i)}
                    aria-expanded={on}
                    className="flex w-full items-start gap-5 py-4 text-left"
                  >
                    <span className="mono mt-1.5 w-7" style={{ color: on ? AI_MODES[i].color : "#64748b" }}>
                      0{i + 1}
                    </span>
                    <span className="flex-1">
                      <span className={`block text-xl transition-colors ${on ? "font-semibold text-white" : "font-light text-slate-400"}`}>
                        {c.t}
                      </span>
                      <motion.span
                        initial={false}
                        animate={{ height: on ? "auto" : 0, opacity: on ? 1 : 0 }}
                        className="block overflow-hidden text-[0.95rem] leading-relaxed text-slate-300/75"
                      >
                        <span className="block pt-2">{c.d}</span>
                      </motion.span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="lg:sticky lg:top-24 lg:self-start">
          <div
            ref={ref}
            onClick={() => (burst.current += 1)}
            className="relative aspect-square w-full cursor-pointer overflow-hidden rounded-[2rem] border border-white/10 bg-[radial-gradient(circle_at_50%_50%,#061436_0%,#010308_70%)]"
          >
            {webgl ? (
              <WebGLBoundary fallback={<FallbackOrb className="h-full w-full" />}>
                <Suspense fallback={null}>
                  <AINetwork quality={quality} active={inView} mode={mode} burst={burst} />
                </Suspense>
              </WebGLBoundary>
            ) : (
              <FallbackOrb className="h-full w-full" />
            )}
            <div className="pointer-events-none absolute left-5 top-5 flex items-center gap-2 mono text-sky-300">
              <span className="h-2 w-2 animate-pulse rounded-full bg-cyan-300 shadow-[0_0_12px_#38e1ff]" />
              NEURAL CORE · INTERACTIVE
            </div>
            <div className="pointer-events-none absolute bottom-5 left-5 right-5 flex justify-between mono text-slate-400">
              <span>CLICK TO FIRE A PULSE</span>
              <span style={{ color: AI_MODES[mode].color }}>{CAPS[mode].t}</span>
            </div>
          </div>
          <p className="mono mt-4 !normal-case !tracking-wide text-slate-500">
            Visualization only — a generative illustration, not a live AI model.
          </p>
        </div>
      </div>
    </section>
  );
}
