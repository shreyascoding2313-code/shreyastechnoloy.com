import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useLocation } from "react-router-dom";
import { Wordmark } from "./Logo";
import { useScroll } from "../lib/scroll";

export const NAV = [
  { id: "home", label: "HOME" },
  { id: "about", label: "ABOUT" },
  { id: "services", label: "SERVICES" },
  { id: "technologies", label: "TECHNOLOGIES" },
  { id: "ai-lab", label: "AI LAB" },
  { id: "projects", label: "PROJECTS" },
  { id: "contact", label: "CONTACT" },
];

export default function Nav() {
  const { goTo } = useScroll();
  const { pathname } = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 40);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    setOpen(false);
    if (pathname !== "/") {
      setActive("");
      return;
    }
    const ids = NAV.map((n) => n.id);
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    const t = window.setTimeout(() => {
      ids.forEach((id) => {
        const el = document.getElementById(id);
        if (el) io.observe(el);
      });
    }, 300);
    return () => {
      window.clearTimeout(t);
      io.disconnect();
    };
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const go = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    setOpen(false);
    goTo(id);
  };

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled || open ? "glass-nav" : "bg-transparent"}`}
      >
        <nav
          aria-label="Primary"
          className={`mx-auto flex max-w-[1500px] items-center justify-between px-5 transition-all duration-500 sm:px-10 ${scrolled ? "py-3" : "py-6"}`}
        >
          <a href="#/" onClick={go("home")} aria-label="SHREYAS TECHNOLOGIES — home">
            <Wordmark compact={scrolled} />
          </a>
          <ul className="hidden items-center gap-8 xl:flex">
            {NAV.map((n) => (
              <li key={n.id}>
                <a
                  href="#/"
                  onClick={go(n.id)}
                  aria-current={active === n.id ? "true" : undefined}
                  className={`mono group relative py-2 transition-colors ${active === n.id ? "text-white" : "text-slate-300/70 hover:text-white"}`}
                >
                  {n.label}
                  <span
                    className={`absolute -bottom-0.5 left-0 h-px bg-cyan-300 shadow-[0_0_10px_#38e1ff] transition-all duration-500 ${active === n.id ? "w-full" : "w-0 group-hover:w-full"}`}
                  />
                </a>
              </li>
            ))}
          </ul>
          <div className="flex items-center gap-3">
            <a href="#/" onClick={go("contact")} className="btn btn-ghost hidden !py-3 sm:inline-flex xl:inline-flex">
              Start a project
            </a>
            <button
              className="relative z-50 flex h-11 w-11 items-center justify-center rounded-full border border-white/20 xl:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              onClick={() => setOpen((o) => !o)}
            >
              <span className="relative block h-3 w-5">
                <span className={`absolute left-0 h-px w-5 bg-white transition-all ${open ? "top-1.5 rotate-45" : "top-0"}`} />
                <span className={`absolute left-0 top-1.5 h-px w-5 bg-white transition-opacity ${open ? "opacity-0" : ""}`} />
                <span className={`absolute left-0 h-px w-5 bg-white transition-all ${open ? "top-1.5 -rotate-45" : "top-3"}`} />
              </span>
            </button>
          </div>
        </nav>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            className="fixed inset-0 z-40 flex flex-col justify-center bg-black/95 px-8 backdrop-blur-xl xl:hidden"
          >
            <div
              className="pointer-events-none absolute inset-0"
              style={{ background: "radial-gradient(circle at 80% 20%, rgba(47,123,255,.3), transparent 55%)" }}
            />
            <ul className="relative space-y-1">
              {NAV.map((n, i) => (
                <motion.li
                  key={n.id}
                  initial={{ y: 30, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.05 * i + 0.1, duration: 0.5 }}
                >
                  <a
                    href="#/"
                    onClick={go(n.id)}
                    className={`block py-2 text-[clamp(1.8rem,8vw,3rem)] font-light tracking-wide ${active === n.id ? "blue-text" : "text-white"}`}
                  >
                    <span className="mono mr-4 text-[0.6rem] text-sky-400/70">0{i + 1}</span>
                    {n.label}
                  </a>
                </motion.li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
