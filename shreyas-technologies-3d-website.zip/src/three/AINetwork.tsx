import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { AI_MODES } from "../lib/store";
import type { Quality } from "../lib/store";

const vert = `
attribute float aSize; attribute float aGlow; varying float vGlow; uniform float uScale;
void main(){ vGlow = aGlow; vec4 mv = modelViewMatrix*vec4(position,1.0);
  gl_PointSize = aSize*(1.0+aGlow*1.8)*uScale/(-mv.z); gl_Position = projectionMatrix*mv; }`;
const frag = `
uniform vec3 uColor; varying float vGlow;
void main(){ float d = length(gl_PointCoord-0.5); if(d>0.5) discard;
  float a = pow(smoothstep(0.5,0.0,d),1.6);
  vec3 c = mix(uColor, vec3(1.0), vGlow*0.6 + a*0.3);
  gl_FragColor = vec4(c, a*(0.55+vGlow*0.8)); }`;

function useGlowMaterial(color: string) {
  const size = useThree((s) => s.size);
  const dpr = useThree((s) => s.viewport.dpr);
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: vert,
        fragmentShader: frag,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        uniforms: { uColor: { value: new THREE.Color(color) }, uScale: { value: 600 } },
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );
  useEffect(() => {
    mat.uniforms.uScale.value = size.height * dpr * 1.2;
  }, [size.height, dpr, mat]);
  return mat;
}

function Network({ quality, mode, burst }: { quality: Quality; mode: number; burst: React.RefObject<number> }) {
  const group = useRef<THREE.Group>(null);
  const core = useRef<THREE.Mesh>(null);
  const nodeMat = useGlowMaterial("#38e1ff");
  const pulseMat = useGlowMaterial("#ffffff");
  const coreMat = useGlowMaterial("#38e1ff");
  const lastBurst = useRef(0);
  const coreGlow = useRef(0);

  const net = useMemo(() => {
    const high = quality === "high";
    const shells = high ? [14, 26, 40] : [9, 16, 22];
    const radii = [1.7, 2.7, 3.6];
    const pos: THREE.Vector3[] = [new THREE.Vector3(0, 0, 0)];
    const shellIdx: number[][] = [];
    shells.forEach((n, s) => {
      const idx: number[] = [];
      for (let i = 0; i < n; i++) {
        const y = 1 - (i / (n - 1)) * 2;
        const r = Math.sqrt(1 - y * y);
        const th = i * 2.399963 + s * 0.8;
        const jitter = 1 + (Math.sin(i * 12.9898 + s * 78.233) * 0.5) * 0.12;
        pos.push(new THREE.Vector3(Math.cos(th) * r, y, Math.sin(th) * r).multiplyScalar(radii[s] * jitter));
        idx.push(pos.length - 1);
      }
      shellIdx.push(idx);
    });
    const out: number[][] = pos.map(() => []);
    const edges: [number, number][] = [];
    const add = (a: number, b: number) => {
      if (!out[a].includes(b)) {
        out[a].push(b);
        edges.push([a, b]);
      }
    };
    shellIdx[0].forEach((i) => add(0, i));
    for (let s = 0; s < 2; s++) {
      shellIdx[s].forEach((a) => {
        const sorted = [...shellIdx[s + 1]].sort((x, y) => pos[a].distanceTo(pos[x]) - pos[a].distanceTo(pos[y]));
        sorted.slice(0, 2).forEach((b) => add(a, b));
      });
    }
    // lateral links inside outer shells
    [1, 2].forEach((s) => {
      shellIdx[s].forEach((a) => {
        const nb = [...shellIdx[s]]
          .filter((x) => x !== a)
          .sort((x, y) => pos[a].distanceTo(pos[x]) - pos[a].distanceTo(pos[y]))[0];
        if (nb !== undefined && a < nb) edges.push([a, nb]);
      });
    });
    const linePos = new Float32Array(edges.length * 6);
    edges.forEach(([a, b], i) => {
      pos[a].toArray(linePos, i * 6);
      pos[b].toArray(linePos, i * 6 + 3);
    });
    return { pos, out, edges, linePos };
  }, [quality]);

  const lineGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(net.linePos, 3));
    return g;
  }, [net]);

  const nodeGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const p = new Float32Array(net.pos.length * 3);
    net.pos.forEach((v, i) => v.toArray(p, i * 3));
    g.setAttribute("position", new THREE.BufferAttribute(p, 3));
    const sizes = new Float32Array(net.pos.length).fill(0.075);
    sizes[0] = 0;
    g.setAttribute("aSize", new THREE.BufferAttribute(sizes, 1));
    g.setAttribute("aGlow", new THREE.BufferAttribute(new Float32Array(net.pos.length), 1));
    return g;
  }, [net]);

  const PULSES = quality === "high" ? 26 : 14;
  const pulses = useRef(
    Array.from({ length: PULSES }, (_, i) => ({ from: 0, to: 0, t: 0, delay: i * 0.18, speed: 0.8 + Math.random() * 0.6 }))
  );
  const pulseGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(PULSES * 3), 3));
    g.setAttribute("aSize", new THREE.BufferAttribute(new Float32Array(PULSES).fill(0.11), 1));
    g.setAttribute("aGlow", new THREE.BufferAttribute(new Float32Array(PULSES).fill(1), 1));
    return g;
  }, [PULSES]);

  const coreGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(3), 3));
    g.setAttribute("aSize", new THREE.BufferAttribute(new Float32Array([1.5]), 1));
    g.setAttribute("aGlow", new THREE.BufferAttribute(new Float32Array([0.4]), 1));
    return g;
  }, []);

  const lineMat = useMemo(
    () =>
      new THREE.LineBasicMaterial({
        color: "#38e1ff",
        transparent: true,
        opacity: 0.2,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    []
  );

  const target = useMemo(() => new THREE.Color(), []);

  useFrame((state, dt) => {
    const m = AI_MODES[mode] ?? AI_MODES[0];
    target.set(m.color);
    [nodeMat, pulseMat, coreMat].forEach((mm) => mm.uniforms.uColor.value.lerp(target, 0.08));
    lineMat.color.lerp(target, 0.08);

    // click burst: restart every pulse at the core
    if (burst.current !== lastBurst.current) {
      lastBurst.current = burst.current;
      coreGlow.current = 1;
      pulses.current.forEach((p, i) => {
        p.from = 0;
        p.to = net.out[0][Math.floor(Math.random() * net.out[0].length)];
        p.t = 0;
        p.delay = i * 0.025;
      });
    }

    const glow = nodeGeo.getAttribute("aGlow") as THREE.BufferAttribute;
    for (let i = 0; i < glow.count; i++) glow.setX(i, Math.max(0, glow.getX(i) - dt * 1.4));

    const pp = pulseGeo.getAttribute("position") as THREE.BufferAttribute;
    pulses.current.forEach((p, i) => {
      if (p.delay > 0) {
        p.delay -= dt;
        pp.setXYZ(i, 0, 0, 0);
        return;
      }
      if (p.to === 0 && p.from === 0) p.to = net.out[0][Math.floor(Math.random() * net.out[0].length)];
      p.t += dt * p.speed * m.speed;
      if (p.t >= 1) {
        glow.setX(p.to, 1);
        if (p.from === 0) coreGlow.current = Math.min(1, coreGlow.current + 0.25);
        const next = net.out[p.to];
        p.from = p.to;
        p.to = next.length ? next[Math.floor(Math.random() * next.length)] : 0;
        if (!next.length) {
          p.from = 0;
          p.to = net.out[0][Math.floor(Math.random() * net.out[0].length)];
        }
        p.t = 0;
      }
      const a = net.pos[p.from];
      const b = net.pos[p.to];
      pp.setXYZ(i, a.x + (b.x - a.x) * p.t, a.y + (b.y - a.y) * p.t, a.z + (b.z - a.z) * p.t);
    });
    pp.needsUpdate = true;
    glow.needsUpdate = true;

    coreGlow.current = Math.max(0, coreGlow.current - dt * 0.8);
    const cg = coreGeo.getAttribute("aGlow") as THREE.BufferAttribute;
    cg.setX(0, 0.35 + coreGlow.current * 0.9 + Math.sin(state.clock.elapsedTime * 2) * 0.12);
    cg.needsUpdate = true;

    if (group.current) {
      group.current.rotation.y += dt * 0.12;
      group.current.rotation.x = THREE.MathUtils.damp(group.current.rotation.x, -state.pointer.y * 0.5, 3, dt);
      group.current.position.x = THREE.MathUtils.damp(group.current.position.x, state.pointer.x * 0.3, 3, dt);
    }
    if (core.current) {
      core.current.rotation.y -= dt * 0.6;
      core.current.rotation.x += dt * 0.3;
      core.current.scale.setScalar(1 + coreGlow.current * 0.25);
    }
  });

  return (
    <group ref={group}>
      <lineSegments geometry={lineGeo} material={lineMat} />
      <points geometry={nodeGeo} material={nodeMat} />
      <points geometry={pulseGeo} material={pulseMat} />
      <points geometry={coreGeo} material={coreMat} />
      <mesh ref={core}>
        <icosahedronGeometry args={[0.42, 1]} />
        <meshBasicMaterial wireframe color="#bfeaff" transparent opacity={0.7} />
      </mesh>
      <mesh>
        <sphereGeometry args={[0.2, 24, 24]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>
    </group>
  );
}

export default function AINetwork({
  quality,
  active,
  mode,
  burst,
}: {
  quality: Quality;
  active: boolean;
  mode: number;
  burst: React.RefObject<number>;
}) {
  return (
    <Canvas
      frameloop={active ? "always" : "never"}
      dpr={[1, quality === "high" ? 1.75 : 1.3]}
      camera={{ position: [0, 0, 9], fov: 45 }}
      gl={{ antialias: true, alpha: true }}
      aria-label="Interactive neural network visualization"
      role="img"
    >
      <Network quality={quality} mode={mode} burst={burst} />
    </Canvas>
  );
}
