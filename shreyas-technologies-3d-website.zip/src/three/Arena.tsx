import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";
import {
  Environment,
  Lightformer,
  MeshReflectorMaterial,
  MeshTransmissionMaterial,
  Sparkles,
} from "@react-three/drei";
import { Bloom, EffectComposer, ToneMapping, Vignette } from "@react-three/postprocessing";
import { ToneMappingMode } from "postprocessing";
import { ctl, PRESETS, prefersReducedMotion } from "../lib/store";
import type { Quality } from "../lib/store";

const damp = THREE.MathUtils.damp;

/* ---------- Shader backdrop: deep midnight nebula dome ---------- */
function BackdropDome() {
  const uniforms = useMemo(() => ({ uTime: { value: 0 } }), []);
  useFrame((s) => {
    uniforms.uTime.value = s.clock.elapsedTime;
  });
  return (
    <mesh scale={50} renderOrder={-10}>
      <sphereGeometry args={[1, 32, 20]} />
      <shaderMaterial
        side={THREE.BackSide}
        depthWrite={false}
        fog={false}
        uniforms={uniforms}
        vertexShader={`varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`}
        fragmentShader={`
          varying vec3 vP; uniform float uTime;
          float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
          float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
            return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
          float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p*=2.02;a*=.5;}return v;}
          void main(){
            vec3 d = normalize(vP);
            vec2 uv = vec2(atan(d.z,d.x)*1.3, d.y*3.0);
            float n = fbm(uv*1.4 + vec2(uTime*0.015, 0.0));
            float horizon = exp(-abs(d.y+0.02)*4.5);
            vec3 col = vec3(0.0,0.004,0.015);
            col += vec3(0.015,0.075,0.30)*horizon*(0.35+n*1.3);
            col += vec3(0.11,0.04,0.32)*smoothstep(0.25,0.95,n)*0.22*(1.0-abs(d.y));
            gl_FragColor = vec4(col,1.0);
          }`}
      />
    </mesh>
  );
}

/* ---------- Volumetric-style light cone (additive fresnel shader) ---------- */
function LightCone({
  position,
  rotationZ,
  color,
  intensity = 0.2,
}: {
  position: [number, number, number];
  rotationZ: number;
  color: string;
  intensity?: number;
}) {
  const uniforms = useMemo(
    () => ({ uColor: { value: new THREE.Color(color) }, uI: { value: intensity }, uTime: { value: 0 } }),
    [color, intensity]
  );
  useFrame((s) => {
    uniforms.uTime.value = s.clock.elapsedTime;
  });
  return (
    <mesh position={position} rotation={[0, 0, rotationZ]} renderOrder={5}>
      <coneGeometry args={[2.4, 11, 40, 1, true]} />
      <shaderMaterial
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        side={THREE.DoubleSide}
        uniforms={uniforms}
        vertexShader={`varying vec3 vN; varying vec3 vV; varying float vH;
          void main(){ vH = uv.y; vec4 mv = modelViewMatrix*vec4(position,1.0);
            vN = normalize(normalMatrix*normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }`}
        fragmentShader={`varying vec3 vN; varying vec3 vV; varying float vH;
          uniform vec3 uColor; uniform float uI; uniform float uTime;
          void main(){
            float f = pow(abs(dot(normalize(vN), normalize(vV))), 2.2);
            float a = f * pow(vH, 1.8) * uI * (0.85 + 0.15*sin(uTime*0.7 + vH*6.0));
            gl_FragColor = vec4(uColor * a, a);
          }`}
      />
    </mesh>
  );
}

/* ---------- Orbital rings with satellites ---------- */
const RING_DEFS = [
  { r: 2.25, tube: 0.011, tilt: [1.25, 0.2, 0.0], speed: 0.38, color: [0.3, 1.6, 2.4] },
  { r: 2.95, tube: 0.014, tilt: [0.55, -0.85, 0.4], speed: -0.26, color: [0.4, 0.8, 3.0] },
  { r: 3.65, tube: 0.008, tilt: [1.5, 0.95, -0.3], speed: 0.18, color: [1.4, 0.8, 2.8] },
] as const;

function Rings() {
  const refs = useRef<(THREE.Group | null)[]>([]);
  useFrame((_, dt) => {
    RING_DEFS.forEach((d, i) => {
      const g = refs.current[i];
      if (g) g.rotation.z += dt * d.speed * ctl.orbit;
    });
  });
  return (
    <group>
      {RING_DEFS.map((d, i) => (
        <group key={i} rotation={d.tilt as unknown as [number, number, number]}>
          <group ref={(el) => void (refs.current[i] = el)}>
            <mesh>
              <torusGeometry args={[d.r, d.tube, 12, 220]} />
              <meshBasicMaterial toneMapped={false} transparent opacity={0.9}>
                <color attach="color" args={[d.color[0], d.color[1], d.color[2]]} />
              </meshBasicMaterial>
            </mesh>
            <mesh position={[d.r, 0, 0]}>
              <sphereGeometry args={[0.055 + i * 0.01, 16, 16]} />
              <meshBasicMaterial toneMapped={false}>
                <color attach="color" args={[d.color[0] * 2, d.color[1] * 2, d.color[2] * 2]} />
              </meshBasicMaterial>
            </mesh>
          </group>
        </group>
      ))}
    </group>
  );
}

/* ---------- The liquid-glass sculpture ---------- */
function Sculpture({
  quality,
  preset,
  emerge,
}: {
  quality: Quality;
  preset: number;
  emerge?: { v: number };
}) {
  const root = useRef<THREE.Group>(null);
  const spin = useRef<THREE.Group>(null);
  const inner = useRef<THREE.Mesh>(null);
  const outer = useRef<THREE.Mesh>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const mat = useRef<any>(null);
  const autoY = useRef(0);
  const tgtColor = useMemo(() => new THREE.Color(), []);
  const tgtAtten = useMemo(() => new THREE.Color(), []);
  const high = quality === "high";
  const rm = useMemo(prefersReducedMotion, []);

  const outerGeo = useMemo(
    () => new THREE.TorusKnotGeometry(1.08, 0.36, high ? 360 : 160, high ? 72 : 28, 2, 3),
    [high]
  );
  const innerGeo = useMemo(
    () => new THREE.TorusKnotGeometry(0.62, 0.085, high ? 240 : 120, high ? 20 : 12, 3, 5),
    [high]
  );

  useFrame((state, dt) => {
    const t = state.clock.elapsedTime;
    const e = emerge ? emerge.v : 1;
    if (root.current) {
      root.current.scale.setScalar(0.05 + 0.95 * e);
      root.current.position.y = Math.sin(t * 0.8) * 0.12 + (1 - e) * -1.2;
    }
    autoY.current += dt * (rm ? 0.03 : 0.22) * (1 + (1 - e) * 4);
    if (spin.current) {
      spin.current.rotation.y = damp(spin.current.rotation.y, autoY.current + ctl.rotY, 6, dt);
      spin.current.rotation.x = damp(spin.current.rotation.x, Math.sin(t * 0.3) * 0.18 + ctl.rotX, 6, dt);
      spin.current.rotation.z = Math.sin(t * 0.25) * 0.08;
    }
    if (inner.current) {
      inner.current.rotation.y -= dt * 0.5;
      inner.current.rotation.x += dt * 0.2;
    }
    if (outer.current) outer.current.rotation.z += dt * 0.05;
    const p = PRESETS[preset] ?? PRESETS[0];
    tgtColor.set(p.color);
    tgtAtten.set(p.atten);
    if (mat.current) {
      mat.current.color.lerp(tgtColor, 0.06);
      if (mat.current.attenuationColor) mat.current.attenuationColor.lerp(tgtAtten, 0.06);
    }
  });

  return (
    <group ref={root}>
      <group ref={spin}>
        <mesh ref={outer} geometry={outerGeo}>
          {high ? (
            <MeshTransmissionMaterial
              ref={mat}
              backside
              backsideThickness={0.6}
              samples={6}
              resolution={512}
              transmission={1}
              thickness={1.1}
              roughness={0.04}
              chromaticAberration={0.35}
              anisotropicBlur={0.25}
              distortion={0.4}
              distortionScale={0.45}
              temporalDistortion={0.18}
              ior={1.4}
              color="#2f6bff"
              attenuationColor="#0a35ff"
              attenuationDistance={1.4}
              envMapIntensity={2.4}
              clearcoat={1}
              clearcoatRoughness={0.05}
            />
          ) : (
            <meshPhysicalMaterial
              ref={mat}
              color="#2f6bff"
              transparent
              opacity={0.8}
              metalness={0.15}
              roughness={0.05}
              clearcoat={1}
              clearcoatRoughness={0.03}
              envMapIntensity={2.6}
              emissive="#0a2a88"
              emissiveIntensity={0.55}
            />
          )}
        </mesh>
        <mesh ref={inner} geometry={innerGeo}>
          <meshPhysicalMaterial color="#e9f1ff" metalness={1} roughness={0.07} envMapIntensity={2.8} />
        </mesh>
        <mesh>
          <icosahedronGeometry args={[0.22, 2]} />
          <meshBasicMaterial toneMapped={false}>
            <color attach="color" args={[0.5, 2.4, 3.2]} />
          </meshBasicMaterial>
        </mesh>
      </group>
      <Rings />
    </group>
  );
}

/* ---------- Floor ---------- */
function Floor({ quality }: { quality: Quality }) {
  return (
    <group position={[0, -2.25, 0]}>
      <mesh rotation-x={-Math.PI / 2}>
        <planeGeometry args={[60, 60]} />
        {quality === "high" ? (
          <MeshReflectorMaterial
            blur={[400, 120]}
            resolution={512}
            mixBlur={1}
            mixStrength={32}
            roughness={1}
            depthScale={1.1}
            minDepthThreshold={0.4}
            maxDepthThreshold={1.4}
            color="#03060e"
            metalness={0.6}
            mirror={0.7}
          />
        ) : (
          <meshStandardMaterial color="#02040a" roughness={0.35} metalness={0.8} />
        )}
      </mesh>
      {[1.7, 3.2].map((r, i) => (
        <mesh key={r} rotation-x={-Math.PI / 2} position-y={0.01}>
          <ringGeometry args={[r, r + 0.018 + i * 0.01, 128]} />
          <meshBasicMaterial toneMapped={false} transparent opacity={0.65 - i * 0.3}>
            <color attach="color" args={[0.2, 1.1, 2.2]} />
          </meshBasicMaterial>
        </mesh>
      ))}
    </group>
  );
}

/* ---------- Camera rig: mouse parallax + scroll zoom + arena mode ---------- */
function CameraRig({
  mode,
  shiftRef,
  cam,
}: {
  mode: "intro" | "hero";
  shiftRef: React.RefObject<THREE.Group | null>;
  cam?: { z: number };
}) {
  const look = useMemo(() => new THREE.Vector3(), []);
  useFrame((state, dt) => {
    const { camera, pointer, size } = state;
    const aspect = size.width / size.height;
    const arena = ctl.arena;
    const sp = mode === "hero" ? ctl.scroll : 0;
    const z = mode === "intro" ? cam?.z ?? 7.6 : 7.8 - arena * 1.1 - sp * 5.2;
    const px = pointer.x * 1.0 * (1 - arena * 0.35);
    const py = pointer.y * 0.55;
    camera.position.x = damp(camera.position.x, px, 3, dt);
    camera.position.y = damp(camera.position.y, 0.7 + py - sp * 0.7, 3, dt);
    camera.position.z = damp(camera.position.z, z, mode === "intro" ? 8 : 3, dt);
    look.set(0, 0.1, 0);
    camera.lookAt(look);

    if (shiftRef.current) {
      let tx = 0;
      let ty = 0;
      if (mode === "hero") {
        const h = 2 * Math.tan(THREE.MathUtils.degToRad(20)) * 7.8;
        const w = h * aspect;
        const free = 1 - arena;
        if (aspect > 1.25) tx = w * 0.2 * free * (1 - sp);
        else ty = h * 0.16 * free * (1 - sp * 0.5);
      }
      shiftRef.current.position.x = damp(shiftRef.current.position.x, tx, 4, dt);
      shiftRef.current.position.y = damp(shiftRef.current.position.y, ty, 4, dt);
    }
  });
  return null;
}

function Slider({ children }: { children: React.ReactNode }) {
  const g = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (g.current) g.current.rotation.y += dt * 0.35;
  });
  return <group ref={g}>{children}</group>;
}

function World({
  mode,
  quality,
  preset,
  emerge,
  cam,
}: {
  mode: "intro" | "hero";
  quality: Quality;
  preset: number;
  emerge?: { v: number };
  cam?: { z: number };
}) {
  const shift = useRef<THREE.Group>(null);
  const high = quality === "high";
  return (
    <>
      <color attach="background" args={["#000208"]} />
      <fog attach="fog" args={["#000208", 10, 30]} />
      <ambientLight intensity={0.12} />
      <pointLight position={[3, 3, 4]} intensity={40} color="#38e1ff" />
      <pointLight position={[-4, 2, -3]} intensity={30} color="#6a4dff" />

      <Environment resolution={high ? 256 : 128} frames={Infinity}>
        <Lightformer form="rect" intensity={4} color="#a8d4ff" position={[0, 6, -3]} scale={[14, 3, 1]} rotation-x={Math.PI / 2} />
        <Lightformer form="rect" intensity={3.2} color="#2f7bff" position={[-7, 1, 2]} scale={[2.5, 10, 1]} rotation-y={Math.PI / 2} />
        <Lightformer form="rect" intensity={3.2} color="#38e1ff" position={[7, 0, 1]} scale={[2.5, 10, 1]} rotation-y={-Math.PI / 2} />
        <Lightformer form="rect" intensity={2} color="#8b6cff" position={[0, -2, -8]} scale={[14, 2, 1]} />
        <Slider>
          <Lightformer form="rect" intensity={7} color="#ffffff" position={[0, 1, 7]} scale={[1.1, 8, 1]} rotation-y={Math.PI} />
          <Lightformer form="rect" intensity={4} color="#7fd0ff" position={[0, 3, -7]} scale={[1.6, 6, 1]} />
        </Slider>
      </Environment>

      <BackdropDome />
      <LightCone position={[-3.6, 1.6, -2]} rotationZ={0.38} color="#2f7bff" intensity={high ? 0.28 : 0.22} />
      <LightCone position={[3.8, 1.6, -3]} rotationZ={-0.4} color="#38e1ff" intensity={high ? 0.22 : 0.17} />
      <LightCone position={[0, 1.8, -5]} rotationZ={0} color="#8b6cff" intensity={0.12} />

      <group ref={shift}>
        <Sculpture quality={quality} preset={preset} emerge={emerge} />
      </group>
      <Floor quality={quality} />

      <Sparkles
        count={high ? 170 : 70}
        scale={[15, 7, 15]}
        size={high ? 3 : 4}
        speed={0.25}
        opacity={0.85}
        color="#8fd4ff"
      />
      <Sparkles count={high ? 40 : 14} scale={[10, 5, 10]} size={5} speed={0.15} opacity={0.7} color="#b49cff" />

      <CameraRig mode={mode} shiftRef={shift} cam={cam} />

      {high && (
        <EffectComposer multisampling={4} enableNormalPass={false}>
          <Bloom intensity={0.85} luminanceThreshold={0.9} luminanceSmoothing={0.25} mipmapBlur />
          <Vignette offset={0.25} darkness={0.85} />
          <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
        </EffectComposer>
      )}
    </>
  );
}

export interface ArenaCanvasProps {
  mode: "intro" | "hero";
  quality: Quality;
  active: boolean;
  preset?: number;
  emerge?: { v: number };
  cam?: { z: number };
  onReady?: () => void;
}

export default function ArenaCanvas({ mode, quality, active, preset = 0, emerge, cam, onReady }: ArenaCanvasProps) {
  useEffect(() => {
    const id = requestAnimationFrame(() => onReady?.());
    return () => cancelAnimationFrame(id);
  }, [onReady]);
  return (
    <Canvas
      frameloop={active ? "always" : "never"}
      dpr={quality === "high" ? [1, 1.75] : [1, 1.4]}
      camera={{ position: [0, 0.7, 7.8], fov: 40, near: 0.1, far: 100 }}
      gl={{ antialias: quality === "low", powerPreference: "high-performance" }}
      aria-label="Interactive 3D liquid-glass sculpture"
      role="img"
    >
      <World mode={mode} quality={quality} preset={preset} emerge={emerge} cam={cam} />
    </Canvas>
  );
}
