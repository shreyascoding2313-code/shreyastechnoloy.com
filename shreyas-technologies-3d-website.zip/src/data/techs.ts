export interface Tech {
  name: string;
  icon: string; // key in ICONS
}
export interface TechCategory {
  id: string;
  label: string;
  blurb: string;
  items: Tech[];
}

export const TECH_CATEGORIES: TechCategory[] = [
  {
    id: "frontend",
    label: "FRONTEND",
    blurb: "Interfaces that load fast and feel alive.",
    items: [
      { name: "React", icon: "react" },
      { name: "Next.js", icon: "next" },
      { name: "HTML5", icon: "html5" },
      { name: "CSS3", icon: "css3" },
      { name: "JavaScript", icon: "js" },
      { name: "TypeScript", icon: "ts" },
      { name: "Angular", icon: "angular" },
      { name: "Vue.js", icon: "vue" },
    ],
  },
  {
    id: "backend",
    label: "BACKEND",
    blurb: "Resilient APIs and services under the surface.",
    items: [
      { name: "Node.js", icon: "node" },
      { name: "Express", icon: "express" },
      { name: "Python", icon: "python" },
      { name: "Django", icon: "django" },
      { name: "Java", icon: "java" },
      { name: "PHP", icon: "php" },
      { name: "Go", icon: "go" },
      { name: ".NET", icon: "dotnet" },
    ],
  },
  {
    id: "database",
    label: "DATABASE",
    blurb: "Data modelled for speed, safety and scale.",
    items: [
      { name: "MongoDB", icon: "mongodb" },
      { name: "PostgreSQL", icon: "postgres" },
      { name: "MySQL", icon: "mysql" },
      { name: "Firebase", icon: "firebase" },
      { name: "Supabase", icon: "supabase" },
      { name: "Redis", icon: "redis" },
    ],
  },
  {
    id: "ai",
    label: "AI & LLM",
    blurb: "Models wired into real products and workflows.",
    items: [
      { name: "OpenAI", icon: "openai" },
      { name: "ChatGPT API", icon: "chatgpt" },
      { name: "Gemini", icon: "gemini" },
      { name: "Claude", icon: "claude" },
      { name: "Llama", icon: "llama" },
      { name: "Hugging Face", icon: "hf" },
      { name: "LangChain", icon: "langchain" },
    ],
  },
  {
    id: "cloud",
    label: "CLOUD & DEVOPS",
    blurb: "Ship continuously. Scale quietly.",
    items: [
      { name: "AWS", icon: "aws" },
      { name: "Azure", icon: "azure" },
      { name: "Google Cloud", icon: "gcloud" },
      { name: "Docker", icon: "docker" },
      { name: "Kubernetes", icon: "k8s" },
      { name: "Vercel", icon: "vercel" },
      { name: "Netlify", icon: "netlify" },
      { name: "GitHub Actions", icon: "gha" },
    ],
  },
  {
    id: "mobile",
    label: "MOBILE",
    blurb: "Native feel on every screen in the pocket.",
    items: [
      { name: "Flutter", icon: "flutter" },
      { name: "React Native", icon: "rn" },
      { name: "Android", icon: "android" },
      { name: "Kotlin", icon: "kotlin" },
      { name: "Swift", icon: "swift" },
    ],
  },
  {
    id: "design",
    label: "DESIGN & 3D",
    blurb: "Where engineering meets cinema.",
    items: [
      { name: "Figma", icon: "figma" },
      { name: "Blender", icon: "blender" },
      { name: "Spline", icon: "spline" },
      { name: "Three.js", icon: "three" },
      { name: "WebGL", icon: "webgl" },
      { name: "GSAP", icon: "gsap" },
    ],
  },
  {
    id: "tools",
    label: "TOOLS & SECURITY",
    blurb: "Craft discipline and a hardened pipeline.",
    items: [
      { name: "Git", icon: "git" },
      { name: "GitHub", icon: "github" },
      { name: "Postman", icon: "postman" },
      { name: "Linux", icon: "linux" },
      { name: "Jenkins", icon: "jenkins" },
      { name: "OWASP", icon: "owasp" },
    ],
  },
];
