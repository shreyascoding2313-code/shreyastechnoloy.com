export interface Service {
  id: string;
  title: string;
  line: string;
  points: string[];
}

export const SERVICES: Service[] = [
  {
    id: "web",
    title: "Website Development",
    line: "Fast, accessible, search-ready websites built to be remembered.",
    points: ["Performance-first builds", "SEO & accessibility baked in", "CMS & e-commerce ready"],
  },
  {
    id: "fullstack",
    title: "Full-stack Development",
    line: "From database to pixel — one team owning the whole stack.",
    points: ["API & data design", "Auth, payments, dashboards", "Tested, documented, deployable"],
  },
  {
    id: "software",
    title: "Software Engineering",
    line: "Clean architecture for products that must keep evolving.",
    points: ["Domain-driven structure", "Code review & CI", "Refactors without fear"],
  },
  {
    id: "ai",
    title: "AI & LLM Solutions",
    line: "Language models integrated where they genuinely create leverage.",
    points: ["LLM API integration", "AI agents & tool use", "Retrieval & data pipelines"],
  },
  {
    id: "mobile",
    title: "Mobile Applications",
    line: "Smooth, native-feeling apps for iOS and Android.",
    points: ["Flutter & React Native", "Offline-first patterns", "Store-ready delivery"],
  },
  {
    id: "cloud",
    title: "Cloud Architecture",
    line: "Infrastructure that scales on demand and stays cost-aware.",
    points: ["AWS · Azure · Google Cloud", "Containers & Kubernetes", "CI/CD automation"],
  },
  {
    id: "security",
    title: "Cybersecurity",
    line: "Security designed in from the first commit, not bolted on.",
    points: ["OWASP-aligned practices", "Secrets & access hardening", "Input validation & rate limiting"],
  },
  {
    id: "uiux",
    title: "UI/UX Design",
    line: "Interfaces designed with clarity, rhythm and intent.",
    points: ["Research to prototype", "Design systems in Figma", "Motion & micro-interaction"],
  },
  {
    id: "3d",
    title: "3D Interactive Websites",
    line: "Real-time WebGL worlds that turn visitors into explorers.",
    points: ["Three.js & React Three Fiber", "Custom shaders & lighting", "Mobile-aware fallbacks"],
  },
  {
    id: "automation",
    title: "Automation",
    line: "Repetitive work, replaced by reliable systems.",
    points: ["Workflow orchestration", "Integrations & webhooks", "AI-assisted processing"],
  },
];
