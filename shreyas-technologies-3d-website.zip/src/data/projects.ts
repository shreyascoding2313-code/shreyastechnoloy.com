export type ProjectCategory = "AI" | "3D Web" | "Mobile" | "Security" | "Automation";

export interface Project {
  slug: string;
  title: string;
  kind: string;
  category: ProjectCategory;
  accent: string;
  accent2: string;
  tagline: string;
  overview: string;
  goals: string[];
  features: string[];
  stack: { name: string; icon: string }[];
}

/** All projects are internal DEMO CONCEPTS created to showcase capability — not client work. */
export const PROJECTS: Project[] = [
  {
    slug: "nebula-analytics",
    title: "NEBULA",
    kind: "AI Analytics Dashboard",
    category: "AI",
    accent: "#38e1ff",
    accent2: "#2f7bff",
    tagline: "Ask your data anything. See the answer move.",
    overview:
      "A demo concept for an analytics workspace where natural-language questions become live charts. It shows how an LLM layer, a query engine and a motion-rich interface can work together.",
    goals: [
      "Turn plain-language questions into structured queries",
      "Keep dashboards readable at a glance",
      "Make every transition communicate change in the data",
    ],
    features: ["Natural-language query bar", "Streaming chart updates", "Anomaly highlighting", "Shareable views"],
    stack: [
      { name: "React", icon: "react" },
      { name: "TypeScript", icon: "ts" },
      { name: "Python", icon: "python" },
      { name: "PostgreSQL", icon: "postgres" },
      { name: "OpenAI", icon: "openai" },
      { name: "LangChain", icon: "langchain" },
    ],
  },
  {
    slug: "orbit-commerce",
    title: "ORBIT",
    kind: "3D Product Storefront",
    category: "3D Web",
    accent: "#8b6cff",
    accent2: "#2f7bff",
    tagline: "Rotate the product. Own the moment.",
    overview:
      "A demo concept for an e-commerce experience built around a real-time 3D product viewer, with material swapping, studio lighting and a lightning-fast checkout flow.",
    goals: [
      "Let shoppers inspect a product from every angle",
      "Keep 3D light enough for mid-range phones",
      "Stay fully accessible with a non-3D fallback",
    ],
    features: ["Interactive 3D viewer", "Live material & colour swap", "Adaptive quality", "Accessible fallback gallery"],
    stack: [
      { name: "Next.js", icon: "next" },
      { name: "Three.js", icon: "three" },
      { name: "GSAP", icon: "gsap" },
      { name: "Blender", icon: "blender" },
      { name: "Node.js", icon: "node" },
    ],
  },
  {
    slug: "pulse-fitness",
    title: "PULSE",
    kind: "Mobile Fitness App",
    category: "Mobile",
    accent: "#2f7bff",
    accent2: "#38e1ff",
    tagline: "Every heartbeat, beautifully measured.",
    overview:
      "A demo concept for a cross-platform fitness companion with activity rings, workout flows and offline-first sync, designed for one-handed use.",
    goals: ["Instant, glanceable activity feedback", "Reliable offline logging", "One codebase, two platforms"],
    features: ["Animated activity rings", "Guided workout timer", "Offline-first sync", "Dark-mode first design"],
    stack: [
      { name: "Flutter", icon: "flutter" },
      { name: "Firebase", icon: "firebase" },
      { name: "Kotlin", icon: "kotlin" },
      { name: "Swift", icon: "swift" },
      { name: "Figma", icon: "figma" },
    ],
  },
  {
    slug: "vault-console",
    title: "VAULT",
    kind: "Security Monitoring Console",
    category: "Security",
    accent: "#38e1ff",
    accent2: "#8b6cff",
    tagline: "Quiet when safe. Loud when it matters.",
    overview:
      "A demo concept for a security operations console that visualises events, access attempts and system health on a single calm screen.",
    goals: ["Surface real signals without alert fatigue", "Role-based access by design", "Auditable, tamper-evident logging"],
    features: ["Live event stream", "Role-based access control", "Rate-limit & anomaly views", "Audit trail"],
    stack: [
      { name: "Go", icon: "go" },
      { name: "React", icon: "react" },
      { name: "Redis", icon: "redis" },
      { name: "Docker", icon: "docker" },
      { name: "OWASP", icon: "owasp" },
      { name: "Linux", icon: "linux" },
    ],
  },
  {
    slug: "flowstate-automation",
    title: "FLOWSTATE",
    kind: "Workflow Automation Builder",
    category: "Automation",
    accent: "#8b6cff",
    accent2: "#38e1ff",
    tagline: "Draw the process. Let it run itself.",
    overview:
      "A demo concept for a visual workflow builder where triggers, AI steps and actions are connected on a canvas and executed reliably in the background.",
    goals: ["Make automation approachable for non-engineers", "Retry & error handling by default", "Pluggable AI processing steps"],
    features: ["Drag-and-connect canvas", "Webhook & schedule triggers", "AI processing nodes", "Run history & retries"],
    stack: [
      { name: "Node.js", icon: "node" },
      { name: "TypeScript", icon: "ts" },
      { name: "Redis", icon: "redis" },
      { name: "Claude", icon: "claude" },
      { name: "Docker", icon: "docker" },
    ],
  },
  {
    slug: "halo-experience",
    title: "HALO",
    kind: "Immersive Portfolio World",
    category: "3D Web",
    accent: "#2f7bff",
    accent2: "#8b6cff",
    tagline: "A website you walk through, not scroll past.",
    overview:
      "A demo concept for an immersive portfolio where scroll drives a cinematic camera through a shader-lit 3D space, with graceful fallbacks for reduced motion.",
    goals: ["Cinematic storytelling on scroll", "60fps on desktop, graceful on mobile", "Respect reduced-motion preferences"],
    features: ["Scroll-driven camera", "Custom GLSL shaders", "Post-processing bloom", "Reduced-motion mode"],
    stack: [
      { name: "React", icon: "react" },
      { name: "Three.js", icon: "three" },
      { name: "WebGL", icon: "webgl" },
      { name: "GSAP", icon: "gsap" },
      { name: "Vercel", icon: "vercel" },
    ],
  },
];
